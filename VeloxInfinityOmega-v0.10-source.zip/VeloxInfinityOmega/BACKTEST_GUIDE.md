# Uji reproduktif

Catat versi terminal/broker, spesifikasi simbol, zona waktu, rentang, mode tick, modal, leverage, biaya, preset, dan hash source. Mulai dari Strategy Tester dengan Every tick based on real ticks saat tersedia dan StartEnabled=true. Pastikan simbol tambahan tersedia serta histori tersinkron. Ekspor report dan journal.

1. Uji EURUSD, lalu tambah XAUUSD dan simbol broker lain. Uji tren naik, tren turun, range, dan volatilitas tinggi. Periksa harga fill, long/short, grid, lot, dan umur posisi.
2. Gunakan partisi berurutan. Optimalkan grid, lot, threshold, horizon, dan risiko pada jendela latih. Bekukan parameter untuk jendela berikutnya dan ulangi walk-forward. Pertahankan satu periode final yang tidak pernah dilihat optimizer.
3. Bandingkan net profit dan return setelah biaya terhadap expectancy, profit factor, equity/balance drawdown, Sharpe, Sortino, Calmar, recovery factor, frekuensi posisi, dan stabilitas lintas jendela.
4. Tambahkan spread melebar, deviasi merugikan, gap, leverage lebih kecil, korelasi meningkat, dan seri kerugian. Catat worst scenario, floating loss maksimum, margin maksimum dan distribusi return. Untuk probability of ruin, definisikan ambang, horizon, biaya, aturan stop-out, lalu gunakan block bootstrap dengan dependensi waktu yang sesuai. Ulangi dengan asumsi berbeda.
5. Forward demo pada akun hedging dan netting. Uji perubahan chart, restart pada basket terbuka, putus koneksi, retcode timeout, order parsial, serta tombol Pause, Close Basket, Close All, dan Emergency. Rekonsiliasi transaksi dari journal dan statement.
6. Laporkan win rate, jumlah trade, rata-rata holding time, loss streak maksimum, eksposur saat kondisi layak, dan hasil pada setiap target +10%, +25%, +50%, dan +100% hanya setelah data mendukung perhitungan.

Pengujian lokal yang dijalankan tersedia di verification. Pemeriksaan referensi Python dan stress aritmetika memakai model independen, sehingga tidak membuktikan perilaku runtime MQL5. Kompilasi, Strategy Tester, walk-forward, Monte Carlo, pengujian restart broker, dan demo belum dilakukan.
