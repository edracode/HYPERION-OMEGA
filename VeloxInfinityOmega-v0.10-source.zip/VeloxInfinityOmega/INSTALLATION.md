# Instalasi MT5

1. Buka MT5 desktop dan pilih File → Open Data Folder. Salin VeloxInfinityOmega.mq5 ke MQL5/Experts. Dependency Trade/Trade.mqh berasal dari Standard Library instalasi MT5.
2. Buka berkas di MetaEditor dan tekan F7. Simpan log kompilasi dan pastikan build menghasilkan VeloxInfinityOmega.ex5 sebelum membuka tester atau demo. Berkas ini belum dikompilasi di lingkungan pembuatan.
3. Sesuaikan Symbols, BrokerPrefix, dan BrokerSuffix. Untuk nama dengan pola campuran, tulis nama broker lengkap di Symbols. Contoh `EURUSD.a,XAUUSD.pro`.
4. Atur CommissionRoundTurnPerLot sesuai mata uang akun. Nilai 0 cocok untuk pengujian tanpa biaya komisi tambahan. Basket menggunakan komisi dan fee deal yang dilaporkan broker serta estimasi biaya tutup dari input.
5. Pada Strategy Tester nonvisual, set StartEnabled=true secara eksplisit bila ingin transaksi berlangsung. Pada demo atau tester visual gunakan tombol Start. Periksa izin algo trading.
6. Gunakan magic yang sama saat restart dan pertahankan semua simbol yang masih memiliki posisi EA. Hindari order dari luar EA pada simbol yang sama pada akun netting.
7. Buka chart minimal 600×400 piksel agar panel tampil utuh. PanelX dan PanelY mengatur posisi.

Bila permintaan order tidak bisa dipastikan, EA mengunci pembukaan baru. Untuk exit ambigu, periksa posisi, order aktif, dan histori broker sebelum melakukan tindakan manual. Lepas EA. Setelah terminal konsisten, variabel Global Variables dengan prefiks `VIO.<login>.<magic>.<server-hash>` menyimpan baseline dan latch. Bersihkan nilai latch dan jurnal hanya setelah dipastikan seluruh order terkait terselesaikan. Pertahankan baseline drawdown agar restart tidak melonggarkan batas. Jangan gunakan magic baru untuk menyembunyikan posisi lama.
