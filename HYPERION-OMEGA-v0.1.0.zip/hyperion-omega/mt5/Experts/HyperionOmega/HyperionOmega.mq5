#property strict
#property version "0.10"
#include "Signals.mqh"

enum HORunMode { HO_OBSERVE, HO_TESTER, HO_DEMO };
input HORunMode RunMode=HO_OBSERVE;
input string Symbols="EURUSD,GBPUSD,USDJPY";
input long MagicBase=81372000;
input int PollMs=50;
input int MaxQuoteAgeMs=1000;
input int MaxSpreadPoints=20;
input int AdditionalCostPoints=8;
input int StopPoints=80;
input int TakePoints=95;
input int HoldSeconds=30;
input int RequestTimeoutMs=5000;
input ulong DeviationPoints=10;
input double RiskPerTradePct=0.1;
input double DailyLossPct=1.0;
input double MaxEstimatedMarginPct=20;
input int MaxPositions=4;
input bool EnableMomentum=true;
input bool EnableReversion=true;
input bool AllowNettingDemo=false;

enum HOControl { HO_STOPPED, HO_RUNNING, HO_PAUSED, HO_FLATTEN };
struct HOSymbol
{
   string name;
   MqlTick last;
   HOFeatures features;
   ulong quote_seen_ms;
   bool initialized;
};
HOSymbol markets[];
HOControl control=HO_STOPPED;
bool tester=false;
bool netting=false;
bool fault=false;
string prefix, intent_key, lock_key;
long account_id;
uint pending_id=0;
ulong pending_deal=0, pending_order=0, pending_position=0;
double pending_volume=0;
bool exits_suspended=false;
bool awaiting=false;
ulong sent_ms=0, last_attempt_ms=0, last_ui_ms=0, worst_us=0;
ulong last_reply_ms=0;
ulong signal_count[HO_STRATEGIES];
bool reply_seen=false, owns_lock=false;
int current_day=0;
double day_equity=0.0;
string status="initializing";
string names[]={"START","STOP","PAUSE","EMERGENCY CLOSE"};

bool OwnMagic(const long magic)
{
   return magic>MagicBase && magic<=MagicBase+HO_STRATEGIES;
}

bool CanSend()
{
   if(tester)
      return RunMode==HO_TESTER;
   double lock=0;
   if(AccountInfoInteger(ACCOUNT_LOGIN)!=account_id || !owns_lock || !GlobalVariableGet(lock_key,lock) || lock!=1)
      return false;
   return RunMode==HO_DEMO && AccountInfoInteger(ACCOUNT_TRADE_MODE)==ACCOUNT_TRADE_MODE_DEMO &&
          TerminalInfoInteger(TERMINAL_CONNECTED) && TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) &&
          MQLInfoInteger(MQL_TRADE_ALLOWED) && AccountInfoInteger(ACCOUNT_TRADE_ALLOWED) &&
          AccountInfoInteger(ACCOUNT_TRADE_EXPERT);
}

bool WriteState(const string key,const double value)
{
   ResetLastError();
   if(GlobalVariableSet(key,value)==0)
      return false;
   GlobalVariablesFlush();
   return true;
}

void Fail(const string reason)
{
   fault=true;
   if(control!=HO_FLATTEN)
      control=HO_PAUSED;
   status=reason;
   Print("HO risk latch: ",reason);
   if(!tester && !WriteState(prefix+"fault",1))
      Print("HO could not persist risk latch, error ",GetLastError());
}

bool UpdateDailyRisk()
{
   MqlDateTime parts={};
   datetime now=tester ? TimeCurrent() : TimeTradeServer();
   double equity=AccountInfoDouble(ACCOUNT_EQUITY);
   if(now<=0 || !TimeToStruct(now,parts) || equity<=0.0)
      return false;
   int day=parts.year*10000+parts.mon*100+parts.day;
   if(day!=current_day)
   {
      string key=prefix+"day."+IntegerToString(day);
      if(tester)
         day_equity=equity;
      else if(GlobalVariableCheck(key))
      {
         if(!GlobalVariableGet(key,day_equity) || day_equity<=0)
            return false;
      }
      else
      {
         day_equity=equity;
         if(!WriteState(key,day_equity))
            return false;
      }
      current_day=day;
   }
   if(equity<=day_equity*(1.0-DailyLossPct/100.0) && !fault)
      Fail("daily equity loss limit reached");
   return true;
}

bool ReadQuote(HOSymbol &m)
{
   MqlTick tick;
   if(!SymbolInfoTick(m.name,tick) || tick.time_msc<=0 || tick.bid<=0 || tick.ask<tick.bid)
      return false;
   ulong now=GetTickCount64();
   if(!m.initialized)
   {
      m.initialized=true;
      m.last=tick;
      return false; // A cached quote at startup is never actionable.
   }
   if(tick.time_msc<m.last.time_msc)
      return false;
   if(tick.time_msc==m.last.time_msc && tick.bid==m.last.bid && tick.ask==m.last.ask)
      return false;
   if(!tester)
   {
      long seconds=(long)TimeTradeServer();
      if(seconds<=0 || seconds*1000-tick.time_msc>MaxQuoteAgeMs+999 || tick.time_msc-seconds*1000>2000)
         return false;
   }
   m.last=tick;
   m.quote_seen_ms=now;
   UpdateFeatures(m.features,(tick.bid+tick.ask)*0.5);
   return true;
}

bool SetFill(const string symbol,MqlTradeRequest &req)
{
   long flags=SymbolInfoInteger(symbol,SYMBOL_FILLING_MODE);
   long mode=SymbolInfoInteger(symbol,SYMBOL_TRADE_EXEMODE);
   if((flags & SYMBOL_FILLING_FOK)!=0 || mode==SYMBOL_TRADE_EXECUTION_INSTANT ||
      mode==SYMBOL_TRADE_EXECUTION_REQUEST)
      req.type_filling=ORDER_FILLING_FOK;
   else if((flags & SYMBOL_FILLING_IOC)!=0)
      req.type_filling=ORDER_FILLING_IOC;
   else
      return false;
   return true;
}

bool DefiniteRejection(const uint code)
{
   switch(code)
   {
      case TRADE_RETCODE_REQUOTE:
      case TRADE_RETCODE_REJECT:
      case TRADE_RETCODE_INVALID:
      case TRADE_RETCODE_INVALID_VOLUME:
      case TRADE_RETCODE_INVALID_PRICE:
      case TRADE_RETCODE_INVALID_STOPS:
      case TRADE_RETCODE_TRADE_DISABLED:
      case TRADE_RETCODE_MARKET_CLOSED:
      case TRADE_RETCODE_NO_MONEY:
      case TRADE_RETCODE_PRICE_CHANGED:
      case TRADE_RETCODE_PRICE_OFF:
      case TRADE_RETCODE_INVALID_FILL:
         return true;
   }
   return false;
}

void ClearIntent()
{
   if(!tester && !WriteState(intent_key,0))
   {
      Fail("could not clear persistent order intent");
      return;
   }
   awaiting=false;
   pending_id=0;
   pending_deal=0;
   pending_order=0;
   pending_position=0;
   pending_volume=0;
}

void ReconcileReply()
{
   if(!awaiting || pending_deal==0 || !HistoryDealSelect(pending_deal))
      return;
   if(pending_order!=0 && !HistoryOrderSelect(pending_order))
      return;
   ulong identifier=(ulong)HistoryDealGetInteger(pending_deal,DEAL_POSITION_ID);
   if(identifier==0)
      return;
   if(pending_position!=0)
   {
      if(PositionSelectByTicket(pending_position) &&
         PositionGetDouble(POSITION_VOLUME)>=pending_volume)
         return;
   }
   else
   {
      bool found=false;
      for(int i=PositionsTotal()-1;i>=0;i--)
      {
         if(PositionGetTicket(i)==0)
            return;
         if((ulong)PositionGetInteger(POSITION_IDENTIFIER)!=identifier)
            continue;
         found=true;
         if(PositionGetDouble(POSITION_SL)<=0 && !fault)
         {
            control=HO_FLATTEN;
            Fail("filled position has no reported stop");
         }
         break;
      }
      if(!found)
      {
         if(!HistorySelectByPosition(identifier))
            return;
         double remaining=0;
         for(int i=0;i<HistoryDealsTotal();i++)
         {
            ulong deal=HistoryDealGetTicket(i);
            if(deal==0)
               return;
            long type=HistoryDealGetInteger(deal,DEAL_TYPE);
            if(type==DEAL_TYPE_BUY || type==DEAL_TYPE_SELL)
               remaining+=HistoryDealGetDouble(deal,DEAL_VOLUME)*(type==DEAL_TYPE_BUY ? 1 : -1);
         }
         if(MathAbs(remaining)>1e-9)
            return;
      }
   }
   ClearIntent();
   if(!fault)
      status="execution reconciled";
}

void HandleReply(const MqlTradeResult &reply)
{
   last_reply_ms=GetTickCount64()-sent_ms;
   reply_seen=true;
   PrintFormat("HO request=%u retcode=%u order=%I64u deal=%I64u RTT_ms=%I64u",
               reply.request_id,reply.retcode,reply.order,reply.deal,last_reply_ms);
   if(DefiniteRejection(reply.retcode))
   {
      // Explicit rearm after broker rejection avoids automatic resend loops.
      ClearIntent();
      exits_suspended=true;
      Fail(StringFormat("broker rejection %u",reply.retcode));
      return;
   }
   if((reply.retcode==TRADE_RETCODE_DONE || reply.retcode==TRADE_RETCODE_DONE_PARTIAL) && reply.deal!=0)
   {
      pending_deal=reply.deal;
      pending_order=reply.order;
      status="awaiting deal history";
      return;
   }
   if(reply.retcode!=TRADE_RETCODE_PLACED)
      Fail(StringFormat("uncertain request outcome %u",reply.retcode));
}

bool Dispatch(MqlTradeRequest &req)
{
   if(!CanSend() || awaiting || GetTickCount64()-last_attempt_ms<(ulong)PollMs)
      return false;
   last_attempt_ms=GetTickCount64();
   MqlTradeCheckResult check={};
   if(!OrderCheck(req,check))
   {
      status=StringFormat("OrderCheck retcode %u",check.retcode);
      if(req.position!=0)
      {
         exits_suspended=true;
         Fail(status);
      }
      return false;
   }
   if(!tester && !GlobalVariableSetOnCondition(intent_key,1,0))
   {
      Fail("previous order intent requires reconciliation");
      return false;
   }
   if(!tester)
      GlobalVariablesFlush();
   awaiting=true;
   pending_position=req.position;
   pending_volume=req.volume;
   sent_ms=GetTickCount64();
   MqlTradeResult reply={};
   ResetLastError();
   bool submitted=tester ? OrderSend(req,reply) : OrderSendAsync(req,reply);
   pending_id=reply.request_id;
   if(tester || !submitted)
      HandleReply(reply);
   return submitted;
}

bool EntryAllowed(const string symbol,const long magic)
{
   int owned=0;
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0)
         return false;
      long existing=PositionGetInteger(POSITION_MAGIC);
      if(OwnMagic(existing))
         owned++;
      if(PositionGetString(POSITION_SYMBOL)==symbol && (netting || existing==magic))
         return false;
   }
   if(owned>=MaxPositions)
      return false;
   for(int i=OrdersTotal()-1;i>=0;i--)
   {
      if(OrderGetTicket(i)==0)
         return false;
      if(OrderGetString(ORDER_SYMBOL)==symbol || OwnMagic(OrderGetInteger(ORDER_MAGIC)))
         return false;
   }
   return true;
}

double RoundPrice(const double price,const double tick_size,const int digits,const bool round_up)
{
   double units=price/tick_size;
   return NormalizeDouble((round_up ? MathCeil(units) : MathFloor(units))*tick_size,digits);
}

void TryEntry(HOSymbol &m,const int strategy,const double score)
{
   if(score==0 || awaiting || fault || control!=HO_RUNNING || !CanSend() ||
      GetTickCount64()-m.quote_seen_ms>(ulong)MaxQuoteAgeMs)
      return;
   const string symbol=m.name;
   long magic=MagicBase+strategy+1;
   if(!EntryAllowed(symbol,magic))
      return;
   double point=SymbolInfoDouble(symbol,SYMBOL_POINT);
   double tick_size=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_SIZE);
   if(point<=0 || tick_size<=0 || m.last.ask-m.last.bid>MaxSpreadPoints*point)
      return;
   int digits=(int)SymbolInfoInteger(symbol,SYMBOL_DIGITS);
   long minimum=SymbolInfoInteger(symbol,SYMBOL_TRADE_STOPS_LEVEL);
   double spread=m.last.ask-m.last.bid;
   double stop=MathMax(StopPoints*point,spread+(minimum+1)*point);
   double take=MathMax(TakePoints*point,(minimum+1)*point);
   bool buy=score>0;
   MqlTradeRequest req={};
   req.action=TRADE_ACTION_DEAL;
   req.symbol=symbol;
   req.magic=(ulong)magic;
   req.type=buy ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   req.price=buy ? m.last.ask : m.last.bid;
   req.sl=RoundPrice(req.price+(buy ? -stop : stop),tick_size,digits,!buy);
   req.tp=RoundPrice(req.price+(buy ? take : -take),tick_size,digits,buy);
   req.deviation=DeviationPoints;
   req.comment=StringFormat("Hyperion:%d",strategy+1);
   double min_lot=SymbolInfoDouble(symbol,SYMBOL_VOLUME_MIN);
   double max_lot=SymbolInfoDouble(symbol,SYMBOL_VOLUME_MAX);
   double step=SymbolInfoDouble(symbol,SYMBOL_VOLUME_STEP);
   if(min_lot<=0 || max_lot<min_lot || step<=0 || req.sl<=0 || req.tp<=0 || !SetFill(symbol,req))
      return;
   double loss=0;
   double stressed_stop=req.sl+(buy ? -1 : 1)*(AdditionalCostPoints+DeviationPoints)*point;
   if(stressed_stop<=0 || !OrderCalcProfit(req.type,symbol,min_lot,req.price,stressed_stop,loss) || loss>=0)
      return;
   double equity=AccountInfoDouble(ACCOUNT_EQUITY);
   if(day_equity<=0)
      return;
   double drawdown_pct=100.0*MathMax(0,1.0-equity/day_equity);
   double risk=equity*RiskPerTradePct/100.0*MathMax(0,1.0-drawdown_pct/DailyLossPct);
   double cap=MathMin(max_lot,risk*min_lot/(-loss));
   if(cap<min_lot)
      return;
   req.volume=NormalizeDouble(min_lot+MathFloor((cap-min_lot)/step)*step,8);
   if(req.volume<min_lot || req.volume>max_lot || (-loss)*req.volume/min_lot>risk)
      return;
   double margin=0;
   double used=AccountInfoDouble(ACCOUNT_MARGIN);
   if(!OrderCalcMargin(req.type,symbol,req.volume,req.price,margin) ||
      used+margin>equity*MaxEstimatedMarginPct/100.0 ||
      margin>AccountInfoDouble(ACCOUNT_MARGIN_FREE))
      return;
   Dispatch(req);
}

bool ExclusiveNettingPosition()
{
   if(!netting || tester)
      return true;
   long identifier=PositionGetInteger(POSITION_IDENTIFIER);
   if(!HistorySelectByPosition((ulong)identifier) || HistoryDealsTotal()==0)
      return false;
   for(int i=0;i<HistoryDealsTotal();i++)
   {
      ulong deal=HistoryDealGetTicket(i);
      if(!deal)
         return false;
      long type=HistoryDealGetInteger(deal,DEAL_TYPE);
      if((type==DEAL_TYPE_BUY || type==DEAL_TYPE_SELL) && !OwnMagic(HistoryDealGetInteger(deal,DEAL_MAGIC)))
         return false;
   }
   return true;
}

bool NoOwnedOrders()
{
   for(int i=OrdersTotal()-1;i>=0;i--)
   {
      if(OrderGetTicket(i)==0 || OwnMagic(OrderGetInteger(ORDER_MAGIC)))
         return false;
   }
   return true;
}

int ManagePositions()
{
   int owned=0;
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(!ticket)
         return -1; // An incomplete snapshot cannot confirm flatness.
      long magic=PositionGetInteger(POSITION_MAGIC);
      if(!OwnMagic(magic))
         continue;
      owned++;
      datetime opened=(datetime)PositionGetInteger(POSITION_TIME);
      if(awaiting || exits_suspended || !CanSend() || (control!=HO_FLATTEN && TimeCurrent()-opened<HoldSeconds))
         continue;
      if(!ExclusiveNettingPosition())
      {
         if(!fault)
            Fail("mixed-owner netting position");
         continue;
      }
      string symbol=PositionGetString(POSITION_SYMBOL);
      bool buy=PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY;
      MqlTick tick;
      if(!SymbolInfoTick(symbol,tick) || tick.bid<=0 || tick.ask<tick.bid)
         continue;
      MqlTradeRequest req={};
      req.action=TRADE_ACTION_DEAL;
      req.position=ticket;
      req.symbol=symbol;
      req.magic=(ulong)magic;
      req.volume=PositionGetDouble(POSITION_VOLUME);
      req.type=buy ? ORDER_TYPE_SELL : ORDER_TYPE_BUY;
      req.price=buy ? tick.bid : tick.ask;
      req.deviation=DeviationPoints;
      req.comment="Hyperion:exit";
      if(SetFill(symbol,req))
         Dispatch(req);
   }
   return owned;
}

void Render(const int owned)
{
   ulong now=GetTickCount64();
   if(now-last_ui_ms<500)
      return;
   last_ui_ms=now;
   string latency=reply_seen ? (string)last_reply_ms+" ms" : "n/a";
   Comment("HYPERION OMEGA | ",EnumToString(RunMode)," | ",EnumToString(control),
           "\n",status," | request pending: ",awaiting," | reply: ",latency,
           "\nBalance: ",DoubleToString(AccountInfoDouble(ACCOUNT_BALANCE),2),
           " | Equity: ",DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY),2),
           " | Floating P/L: ",DoubleToString(AccountInfoDouble(ACCOUNT_PROFIT),2),
           " | EA positions: ",owned,
           "\nMax event work: ",worst_us," us | symbol count: ",ArraySize(markets),
           "\nSignals observed: momentum ",signal_count[0]," | mean reversion ",signal_count[1]);
}

void Pump()
{
   ulong started=GetMicrosecondCount();
   ReconcileReply();
   if(awaiting && !fault && GetTickCount64()-sent_ms>(ulong)RequestTimeoutMs)
      Fail("order timeout; reconcile before clearing intent");
   bool risk_ready=RunMode!=HO_OBSERVE && AccountInfoInteger(ACCOUNT_LOGIN)==account_id &&
                   (tester || TerminalInfoInteger(TERMINAL_CONNECTED)) && UpdateDailyRisk();
   int owned=ManagePositions();
   if(control==HO_FLATTEN && owned==0 && !awaiting && CanSend() && NoOwnedOrders())
   {
      control=HO_STOPPED;
      status="flat confirmed for this EA in terminal snapshot";
   }
   int winner_market=-1, winner_strategy=-1;
   double winner_score=0, winner_priority=0;
   for(int i=0;i<ArraySize(markets);i++)
   {
      if(!ReadQuote(markets[i]))
         continue;
      MqlTick quote=markets[i].last;
      double point=SymbolInfoDouble(markets[i].name,SYMBOL_POINT);
      if(point<=0)
         continue;
      double scores[HO_STRATEGIES];
      EvaluateSignals(markets[i].features,(quote.bid+quote.ask)*0.5,quote.ask-quote.bid,
                      AdditionalCostPoints*point,scores);
      if(!EnableMomentum)
         scores[0]=0;
      if(!EnableReversion)
         scores[1]=0;
      for(int strategy=0;strategy<HO_STRATEGIES;strategy++)
      {
         if(scores[strategy]==0)
            continue;
         signal_count[strategy]++;
         if(!risk_ready || fault || awaiting || control!=HO_RUNNING ||
            quote.ask-quote.bid>MaxSpreadPoints*point)
            continue;
         double priority=MathAbs(scores[strategy])/markets[i].features.movement;
         if(priority>winner_priority && EntryAllowed(markets[i].name,MagicBase+strategy+1))
         {
            winner_market=i;
            winner_strategy=strategy;
            winner_score=scores[strategy];
            winner_priority=priority;
         }
      }
   }
   if(winner_market>=0)
      TryEntry(markets[winner_market],winner_strategy,winner_score);
   ulong elapsed=GetMicrosecondCount()-started;
   if(elapsed>worst_us)
      worst_us=elapsed;
   Render(owned);
}

int OnInit()
{
   if(MagicBase<=0 || MagicBase>2000000000 || PollMs<20 || PollMs>1000 ||
      StopPoints<=0 || TakePoints<=0 || HoldSeconds<1 || HoldSeconds>300 ||
      MaxQuoteAgeMs<100 || MaxQuoteAgeMs>10000 || AdditionalCostPoints<0 || AdditionalCostPoints>100000 ||
      DeviationPoints>10000 || MaxSpreadPoints<=0 || RequestTimeoutMs<1000 ||
      RiskPerTradePct<=0 || RiskPerTradePct>1 || DailyLossPct<=0 || DailyLossPct>5 ||
      MaxPositions<1 || MaxEstimatedMarginPct<=0 || MaxEstimatedMarginPct>50)
      return INIT_PARAMETERS_INCORRECT;
   tester=MQLInfoInteger(MQL_TESTER)!=0;
   account_id=AccountInfoInteger(ACCOUNT_LOGIN);
   netting=AccountInfoInteger(ACCOUNT_MARGIN_MODE)!=ACCOUNT_MARGIN_MODE_RETAIL_HEDGING;
   if((RunMode==HO_TESTER && !tester) ||
      (RunMode==HO_DEMO && (tester || account_id<=0 || (netting && !AllowNettingDemo) ||
       AccountInfoInteger(ACCOUNT_TRADE_MODE)!=ACCOUNT_TRADE_MODE_DEMO)))
      return INIT_FAILED;
   if(RunMode==HO_OBSERVE)
   {
      Print("HO observe mode samples quotes and evaluates signals without submitting orders.");
   }
   string configured[];
   if(StringSplit(Symbols,',',configured)<1 || ArraySize(configured)>32)
      return INIT_PARAMETERS_INCORRECT;
   for(int i=0;i<ArraySize(configured);i++)
   {
      string symbol=configured[i];
      StringTrimLeft(symbol);
      StringTrimRight(symbol);
      if(symbol=="" || !SymbolSelect(symbol,true))
         return INIT_PARAMETERS_INCORRECT;
      for(int j=0;j<i;j++)
         if(markets[j].name==symbol)
            return INIT_PARAMETERS_INCORRECT;
      if(ArrayResize(markets,i+1)<0)
         return INIT_FAILED;
      markets[i].name=symbol;
   }
   prefix="HO."+IntegerToString(account_id)+"."+IntegerToString(MagicBase)+".";
   lock_key=prefix+"lock";
   intent_key=prefix+"intent";
   if(RunMode==HO_DEMO)
   {
      if(!GlobalVariableCheck(lock_key))
         GlobalVariableTemp(lock_key);
      if(!GlobalVariableSetOnCondition(lock_key,1,0))
         return INIT_FAILED;
      owns_lock=true;
      if(!GlobalVariableCheck(intent_key) && !WriteState(intent_key,0))
         return INIT_FAILED;
      double intent;
      if(!GlobalVariableGet(intent_key,intent))
         return INIT_FAILED;
      awaiting=intent!=0;
      fault=awaiting || GlobalVariableCheck(prefix+"fault");
      control=HO_STOPPED;
      status=awaiting ? "persistent unresolved order intent" : "ready";
   }
   else if(RunMode==HO_TESTER)
   {
      control=HO_RUNNING;
      status="tester ready";
   }
   else
      status="observing";
   for(int i=0;i<ArraySize(names);i++)
   {
      string name="HO."+names[i];
      if(!ObjectCreate(0,name,OBJ_BUTTON,0,0,0))
         continue;
      ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_LEFT_LOWER);
      ObjectSetInteger(0,name,OBJPROP_XDISTANCE,10+135*i);
      ObjectSetInteger(0,name,OBJPROP_YDISTANCE,38);
      ObjectSetInteger(0,name,OBJPROP_XSIZE,130);
      ObjectSetInteger(0,name,OBJPROP_YSIZE,24);
      ObjectSetString(0,name,OBJPROP_TEXT,names[i]);
   }
   return EventSetMillisecondTimer(PollMs) ? INIT_SUCCEEDED : INIT_FAILED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   if(owns_lock)
      GlobalVariableDel(lock_key);
   for(int i=0;i<ArraySize(names);i++)
      ObjectDelete(0,"HO."+names[i]);
   Comment("");
}

void OnTick() { Pump(); }
void OnTimer() { Pump(); }

void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &name)
{
   if(id!=CHARTEVENT_OBJECT_CLICK)
      return;
   ObjectSetInteger(0,name,OBJPROP_STATE,false);
   if(name=="HO.EMERGENCY CLOSE" && RunMode!=HO_OBSERVE)
   {
      exits_suspended=false;
      control=HO_FLATTEN;
      status=CanSend() ? "flatten requested" : "flatten unavailable in current mode or connection";
   }
   else if(control==HO_FLATTEN)
      return;
   else if(name=="HO.STOP")
      control=HO_STOPPED;
   else if(name=="HO.PAUSE")
      control=HO_PAUSED;
   else if(name=="HO.START" && !fault && RunMode!=HO_OBSERVE && CanSend())
      control=HO_RUNNING;
   Pump();
}

void OnTradeTransaction(const MqlTradeTransaction &tx,const MqlTradeRequest &req,const MqlTradeResult &reply)
{
   if(awaiting && pending_id!=0 && tx.type==TRADE_TRANSACTION_REQUEST &&
      OwnMagic((long)req.magic) && reply.request_id==pending_id)
      HandleReply(reply);
}
