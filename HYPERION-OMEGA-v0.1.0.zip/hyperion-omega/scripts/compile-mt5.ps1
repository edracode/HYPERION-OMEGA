param(
    [Parameter(Mandatory)] [string]$MetaEditor,
    [Parameter(Mandatory)] [string]$TerminalData,
    [string]$LogDirectory = (Join-Path $PSScriptRoot '..\compile-logs')
)
$ErrorActionPreference = 'Stop'
$editorPath = (Resolve-Path -LiteralPath $MetaEditor).Path
$terminalPath = (Resolve-Path -LiteralPath $TerminalData).Path
$root = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..\mt5')).Path
$null = New-Item -ItemType Directory -Force -Path $LogDirectory
$logPath = (Resolve-Path -LiteralPath $LogDirectory).Path
$targets = @(
    @{ Folder = 'Experts\HyperionOmega'; Name = 'HyperionOmega' },
    @{ Folder = 'Scripts\HyperionOmega'; Name = 'ExportBidAsk' }
)
foreach ($target in $targets) {
    $destination = Join-Path (Join-Path $terminalPath 'MQL5') $target.Folder
    $null = New-Item -ItemType Directory -Force -Path $destination
    Copy-Item -Path (Join-Path (Join-Path $root $target.Folder) '*') -Destination $destination -Force
    $source = Join-Path $destination ($target.Name + '.mq5')
    $binary = [System.IO.Path]::ChangeExtension($source, '.ex5')
    $log = Join-Path $logPath ($target.Name + '.log')
    $started = [System.DateTime]::UtcNow.AddSeconds(-2)
    if (Test-Path -LiteralPath $log) { Remove-Item -LiteralPath $log }
    $null = Start-Process -FilePath $editorPath -ArgumentList @(
        ('/compile:"{0}"' -f $source), ('/log:"{0}"' -f $log)
    ) -Wait -PassThru
    if (!(Test-Path -LiteralPath $log) -or !(Test-Path -LiteralPath $binary)) {
        throw "Expected a new compilation log and binary for $source"
    }
    $logText = Get-Content -LiteralPath $log -Raw
    if ($logText -notmatch '(?im)\b0 errors?,\s*0 warnings?\b' -or
        (Get-Item -LiteralPath $binary).LastWriteTimeUtc -lt $started) {
        throw "Compilation was not verified. Inspect $log"
    }
    Get-FileHash -Algorithm SHA256 -LiteralPath $source, $binary, $log
}
