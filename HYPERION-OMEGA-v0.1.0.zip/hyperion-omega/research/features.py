"""Deterministic indicator registry with causal, bounded-cache evaluation."""
from dataclasses import dataclass
from functools import lru_cache
from itertools import product

import numpy as np
import pandas as pd


PRICE_METHODS = (
    "ema_gap", "sma_gap", "ema_residual", "sma_residual", "roc",
    "zscore", "rsi_center", "range_position", "vol_ratio", "spread_pressure",
)


@dataclass(frozen=True)
class Feature:
    method: str
    fast: int
    slow: int

    @property
    def id(self) -> str:
        return f"{self.method}:{self.fast}:{self.slow}"


def feature_registry() -> tuple[Feature, ...]:
    return tuple(
        Feature(method, fast, slow)
        for method, fast, slow in product(PRICE_METHODS, range(3, 35), range(40, 101, 4))
    )


class FeatureEngine:
    def __init__(self, bid: np.ndarray, ask: np.ndarray, point: float):
        self.mid = pd.Series(((bid + ask) * 0.5) / point)
        self.spread = pd.Series((ask - bid) / point)
        self.delta = self.mid.diff()
        self.series = {"mid": self.mid, "spread": self.spread,
                       "abs_delta": self.delta.abs(),
                       "gain": self.delta.clip(lower=0.0),
                       "loss": (-self.delta).clip(lower=0.0)}
        self.indicator = lru_cache(maxsize=32)(self._indicator)

    def _indicator(self, kind: str, source: str, window: int) -> np.ndarray:
        values = self.series[source]
        if kind == "ema":
            return values.ewm(span=window, adjust=False, min_periods=window).mean().to_numpy()
        roll = values.rolling(window)
        return getattr(roll, kind)().to_numpy()

    def compute(self, f: Feature) -> np.ndarray:
        a, b = f.fast, f.slow
        mid = self.mid.to_numpy()
        normalizer = self.indicator("ema", "abs_delta", b)
        def divide(numerator, denominator):
            return np.divide(numerator, denominator, out=np.full_like(mid, np.nan),
                             where=np.isfinite(denominator) & (denominator > 0))
        if f.method == "ema_gap":
            return divide(self.indicator("ema", "mid", a) - self.indicator("ema", "mid", b), normalizer)
        if f.method == "sma_gap":
            return divide(self.indicator("mean", "mid", a) - self.indicator("mean", "mid", b), normalizer)
        if f.method == "ema_residual":
            return divide(mid - self.indicator("ema", "mid", a), normalizer)
        if f.method == "sma_residual":
            return divide(mid - self.indicator("mean", "mid", a), normalizer)
        if f.method == "roc":
            return divide(self.mid.diff(a).to_numpy(), normalizer)
        if f.method == "zscore":
            return divide(mid - self.indicator("mean", "mid", a), self.indicator("std", "mid", b))
        if f.method == "rsi_center":
            gain = self.indicator("ema", "gain", a)
            loss = self.indicator("ema", "loss", a)
            scale = divide(self.indicator("ema", "abs_delta", a), normalizer)
            return divide(gain - loss, gain + loss) * scale * 4
        if f.method == "range_position":
            low = self.indicator("min", "mid", a)
            high = self.indicator("max", "mid", a)
            return divide(2 * mid - low - high, high - low) * divide((high - low), normalizer) / np.sqrt(a)
        if f.method == "vol_ratio":
            return np.sign(self.mid.diff(a).to_numpy()) * divide(self.indicator("ema", "abs_delta", a), normalizer)
        if f.method == "spread_pressure":
            smoothed_spread = self.indicator("mean", "spread", a)
            return divide(self.mid.diff(a).to_numpy(), normalizer + smoothed_spread)
        raise ValueError(f"Unknown feature {f.method}")
