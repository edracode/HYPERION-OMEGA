# Verifikasi v0.1.0 — 21 November 2026

| Pemeriksaan | Hasil |
| --- | --- |
| Python unittest | 11 lulus. Cakupan mencakup identitas grid, kausalitas 10 keluarga fitur, bid/ask tidak valid, biaya, latency, timestamp duplikat, gap pada stop, pemisahan periode, Holm, bootstrap dan ensemble. |
| Benchmark Python | Terukur pada 20.000 kutipan sintetis dan 60 kandidat. Lihat [hasil mentah](BENCHMARK_PYTHON.json). Dataset ini digunakan untuk mengukur biaya komputasi. |
| Kompilasi MQL5 dan Strategy Tester | Belum dijalankan. Lingkungan Linux tidak memiliki MetaEditor. Percobaan mengambil installer resmi menghasilkan HTTP 403. |
| Backtest pasar, walk-forward dan AI pada pasar | Belum dijalankan pada data pasar. Sumber publik yang dicoba mengembalikan HTTP 429. Uji perangkat lunak menggunakan fixture terkontrol. |
| Eksekusi dan lifecycle broker | Belum diverifikasi. Tidak ada terminal atau sesi demo broker dalam lingkungan ini. |
| Profitabilitas dan deployment live | Belum terverifikasi. Tahap ini belum memiliki bukti out-of-sample, laporan demo atau persetujuan live. |

Skrip kompilasi Windows, eksportir data, dan urutan penerimaan tersedia dalam [prosedur MT5](MT5.md).
