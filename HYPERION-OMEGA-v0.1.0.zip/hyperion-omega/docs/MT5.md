# Instalasi, kompatibilitas, dan pemulihan MT5

1. Di MT5 desktop buka **File → Open Data Folder** untuk mengetahui `TerminalData`. Jalankan skrip di bawah dengan MetaEditor Windows dan folder data terminal. Untuk kompilasi GUI, tempatkan isi `mt5/` di dalam `MQL5/` lalu buka kedua `.mq5` dan tekan F7.
2. Simpan log kompilasi dan SHA-256 `.ex5`. Skrip memeriksa keberadaan binary baru dan ringkasan `0 errors, 0 warnings` pada log berbahasa Inggris.
3. Gunakan Strategy Tester dengan `RunMode=HO_TESTER`, profil `EURUSD-Tester.set`, dan model **Every tick based on real ticks**. Ganti nama simbol sesuai broker. Bekukan tanggal train, walk-forward, dan holdout. Arsipkan laporan, Journal, terminal build, nama server, mode akun, spesifikasi simbol, spread, komisi, dan interval data.
4. Untuk ekspor, jalankan `ExportBidAsk` dari Navigator. Masukkan simbol persis seperti broker dan jendela waktu. Output berada pada `MQL5/Files`. Gunakan hanya ekspor yang sukses di Journal. Periksa gap dan kelengkapan sesi terhadap sumber.

~~~powershell
.\scripts\compile-mt5.ps1 -MetaEditor 'C:\Broker MT5\metaeditor64.exe' -TerminalData 'C:\Users\Anda\AppData\Roaming\MetaQuotes\Terminal\ID'
~~~

| Mode | Perilaku |
| --- | --- |
| `HO_OBSERVE` | Default, menghitung sinyal dan menampilkan penghitung. |
| `HO_TESTER` | Order simulasi dalam Strategy Tester. |
| `HO_DEMO` | Order asinkron setelah **START**, pemeriksaan akun demo, dan izin Algo Trading. |

Gunakan satu terminal dan satu akun demo khusus HYPERION per `MagicBase`. Pada akun hedging, magic mengidentifikasi strategi, dengan maksimum satu posisi per strategi per simbol. Akun netting memiliki satu posisi agregat per simbol. Gunakan `AllowNettingDemo=true` hanya pada simbol khusus EA. Asinkron berarti terminal mengirim request tanpa menunggu respons broker sebelum fungsi pengiriman kembali. EA menahan intent lain sampai status terminal direkonsiliasi. Broker harus menyediakan bid/ask dan mendukung market order FOK/IOC. Sesuaikan points dan preset menurut spesifikasi simbol.

**PAUSE** dan **STOP** menahan entri. Posisi EA tetap dikelola oleh time exit dan bracket server. **EMERGENCY CLOSE** meminta penutupan posisi milik EA secara serial. Status flat dikonfirmasi setelah snapshot posisi dan order sesuai. Terminal putus, penolakan broker atau status ambigu dapat menunda penutupan. Broker dapat mengeksekusi stop di luar harga stop saat terjadi gap. Drawdown harian dihitung dari equity akun terhadap snapshot pertama pada hari server, termasuk P/L posisi lain dan dampak deposit atau penarikan.

## Matriks penerimaan broker

| Skenario | Bukti yang diperlukan |
| --- | --- |
| Startup dan rekoneksi | Penolakan order pada akun real, startup STOPPED, dua jenis sinyal dapat terdeteksi, order hanya setelah START. |
| Hedging bersamaan | Posisi overlap dan magic strategi berbeda. Cocokkan request, order, deal, dan posisi. |
| Netting | Uji akun khusus demo terpisah. Satu posisi per simbol. Posisi manual menghalangi entri pada simbol itu. |
| Penolakan dan status ambigu | Invalid stops, market closed, requote, timeout atau fill parsial. Periksa intent dan deduplikasi. |
| Recovery | Putus terminal saat request lalu restart. Cocokkan order, posisi, riwayat deal dan saldo sebelum rearm. |
| Batas risiko | Spread lebar, margin, daily loss dan emergency close. Periksa konfirmasi posisi di Journal. |
| Forward paper | Ukur round-trip costs, durasi, P/L bersih, error, latency, max drawdown dan deviasi dari tester. |

Untuk memulihkan intent atau fault tersimpan, hentikan EA dan simpan Journal serta Experts logs. Cocokkan order aktif, magic, waktu, deal ID, dan posisi. Kelola posisi yang masih terbuka melalui terminal demo bila EA tidak dapat mengirim penutupan. Jika hasil request tetap ambigu, konfirmasikan ke broker. Setelah status dipastikan, hapus `HO.<login>.<MagicBase>.intent` dan `.fault` melalui **Tools → Global Variables**, pasang ulang EA, lalu mulai manual. Pertahankan baseline risiko harian `.day.<YYYYMMDD>`. Terminal lain tidak berbagi lock ini.

Acuan [OrderCalcProfit](https://www.mql5.com/en/docs/trading/ordercalcprofit), [mode akun](https://www.mql5.com/en/docs/constants/environment_state/accountinformation), [timer](https://www.mql5.com/en/docs/eventfunctions/eventsetmillisecondtimer), dan [Strategy Tester](https://www.mql5.com/en/book/automation/tester/tester_ticks).
