import tempfile
import unittest
from pathlib import Path

import numpy as np

from research.features import Feature, FeatureEngine, feature_registry
from research.replay import Costs, DAY_MS, Quotes, replay
from research.search import block_bootstrap, candidates, holm, metrics, run
from research.train import train


COST = Costs(0, 0, 0, 5, 1000, 0)


def fixture(days, ticks, seed=123):
    rng = np.random.default_rng(seed)
    timestamps = 1_735_689_600_000 + np.repeat(np.arange(days), ticks) * DAY_MS
    timestamps += np.tile(np.arange(ticks), days) * 500
    bid = 10_000 + np.cumsum(rng.normal(0, 1, len(timestamps)))
    return Quotes(timestamps, bid, bid + .15, 1)


class ResearchTest(unittest.TestCase):
    def test_registry_and_candidate_uniqueness(self):
        features = feature_registry()
        self.assertEqual(len(features), 5120)
        self.assertEqual(len({f.id for f in features}), len(features))
        self.assertEqual(len({c.id for c in candidates(features)}), 245760)

    def test_features_have_causal_prefix_for_every_family(self):
        q = fixture(1, 260)
        full = FeatureEngine(q.bid, q.ask, q.point)
        short = FeatureEngine(q.bid[:200], q.ask[:200], q.point)
        for f in feature_registry()[::512]:
            with self.subTest(f=f.method):
                result = full.compute(f)
                self.assertTrue(np.isfinite(result[180]))
                np.testing.assert_allclose(short.compute(f), result[:200], equal_nan=True)

    def test_only_enter_after_signal_and_charge_all_costs(self):
        t = np.arange(8) * 200 + DAY_MS
        bid = np.array([100, 100, 101, 105, 107, 107, 108, 108], dtype=float)
        q = Quotes(t, bid, bid + 2, 1)
        result = replay(q, np.array([1, 0, 0, 0, 0, 0, 0, 0]), 0, len(t),
                        Costs(1.0, .5, 250, 5, 1000, 0), 1000, 20, 3)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].opened_ms, t[2])
        self.assertEqual(result[0].closed_ms, t[4])
        self.assertEqual(result[0].net_points, 1.5)
        self.assertEqual(result[0].reason, "target")

    def test_absolute_stop_gap_for_short(self):
        t = np.arange(4) * 200 + DAY_MS
        bid = np.array([100, 100, 115, 108], dtype=float)
        q = Quotes(t, bid, bid + 1, 1)
        trade, = replay(q, np.array([-1, 0, 0, 0]), 0, 4, COST, 1000, 4, 9)
        self.assertEqual(trade.reason, "stop")
        self.assertEqual(trade.net_points, -16)

    def test_zero_latency_does_not_use_earlier_duplicate_timestamp_for_exit(self):
        t = np.array([100, 200, 300, 400, 400, 500]) + DAY_MS
        bid = np.array([100, 100, 100, 97, 109, 111], dtype=float)
        q = Quotes(t, bid, bid + 1, 1)
        trade, = replay(q, np.array([0, 1, 0, 0, 0, 0]), 0, 6, COST, 100, 50, 50)
        self.assertEqual(trade.net_points, -4)
        self.assertEqual(trade.reason, "time")

    def test_replay_respects_split_boundaries_and_stale_quote(self):
        t = np.array([100, 200, 300, 2000, 2100]) + DAY_MS
        bid = np.full(len(t), 100.)
        q = Quotes(t, bid, bid + 1, 1)
        active = np.array([0, 0, 1, 0, 0])
        self.assertEqual(replay(q, active, 0, 3, COST, 1000, 4, 9), [])
        self.assertEqual(replay(q, active, 0, len(t), COST, 1000, 4, 9), [])

    def test_invalid_quote_files(self):
        with tempfile.TemporaryDirectory() as folder:
            file = Path(folder) / "test.csv"
            for body in ("200,1,2\n100,1,2", "100,2,1\n200,1,2", "100,1,inf\n200,1,2",
                         "9223372036854775900,1,2\n9223372036854775901,1,2"):
                with self.subTest(body=body):
                    file.write_text(f"time_msc,bid,ask\n{body}\n")
                    with self.assertRaises(ValueError):
                        Quotes.read(file, 1)

    def test_holm_step_down(self):
        self.assertEqual(holm({"a": .001, "b": .026, "c": .04}), ["a"])
        self.assertEqual(holm({"a": .002, "b": .015, "c": .04}), ["a", "b", "c"])

    def test_bootstrap_and_underpowered_sample(self):
        result = block_bootstrap(np.ones(15), trials=10)
        self.assertEqual(result["net_points_95_interval"], [15, 15])
        self.assertIsNone(block_bootstrap(np.ones(5)))
        empty = metrics([], np.arange(10))
        self.assertIsNone(empty["profit_factor"])
        self.assertIsNone(empty["daily_sharpe_252"])

    def test_full_search_produces_gates_without_claiming_promotion(self):
        q = fixture(49, 150)
        result = run(q, Costs(.2, .1, 50, 3, 1000, 0), 16, 20, 6, 10)
        self.assertEqual(len(result["walk_forward"]), 3)
        self.assertEqual(result["candidates_per_selection"], 16)
        self.assertTrue(result["promotion"].startswith("blocked_"))

    def test_ensemble_reports_disjoint_holdout_and_finite_calibration_metrics(self):
        q = fixture(20, 350)
        _, report = train(q, 2000, .4)
        self.assertAlmostEqual(sum(report["weights"].values()), 1)
        self.assertGreater(report["test_utc_day_start"], q.time[0] // DAY_MS)
        self.assertTrue(np.isfinite(report["test_ensemble"]["log_loss"]))


if __name__ == "__main__":
    unittest.main()
