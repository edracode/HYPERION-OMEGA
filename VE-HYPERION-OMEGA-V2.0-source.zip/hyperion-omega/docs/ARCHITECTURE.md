# Arsitektur HYPERION OMEGA v0.1.0

~~~mermaid
flowchart TD
    A["Quote broker MT5"] --> B["Sampling dan fitur inkremental"]
    B --> C["Momentum dan mean reversion"]
    C --> D["Prioritas sinyal dan batas portofolio"]
    D --> E["OrderCheck dan intent persisten"]
    E --> F["Eksekusi dan rekonsiliasi broker"]
    F --> G["Panel status dan Journal"]
~~~

~~~mermaid
flowchart TD
    A["Ekspor bid/ask broker"] --> B["Registri fitur dan generator kandidat"]
    B --> C["Replay dan seleksi bergulir"]
    C --> D["Holdout, stress, sensitivitas, dan bootstrap"]
    A --> E["Pelatihan ensemble offline"]
    E --> F["Metrik probabilitas holdout"]
~~~

## Kontrak modul

| Modul | Masukan dan keluaran | Invarian |
| --- | --- | --- |
| EA `ReadQuote` | Simbol broker → snapshot quote | Tolak quote mundur, cacat, duplikat, atau terlalu lama untuk demo. |
| EA `Signals` | Mid dan spread → dua skor bertanda dalam satuan harga | EMA inkremental dan skor hanya membaca observasi yang sudah tiba. Ambang biaya merupakan filter riset berbasis points. |
| EA `Pump` | Skor semua simbol → maksimal satu intent baru per event | Handler MT5 serial. Skor dibagi volatilitas perubahan mid untuk menentukan prioritas. Kedua strategi bisa memegang posisi terpisah di akun hedging. |
| EA `TryEntry` | Intent, spesifikasi simbol, dan akun → request | SL dan TP server-side, sizing berbasis estimasi kerugian, batas spread, margin, dan posisi, serta pengurangan risiko setelah drawdown harian. |
| EA `Dispatch` | Request tervalidasi → request ID dan hasil broker | Satu order in-flight. Market order FOK/IOC. Simpan intent sebelum I/O, gunakan `OrderSend` di tester dan `OrderSendAsync` di demo. |
| EA `ReconcileReply` | Retcode, order, deal dan posisi → konfirmasi atau jeda | Cocokkan ID request, magic, riwayat dan posisi. Status ambigu atau timeout menahan pengiriman sampai rekonsiliasi. |
| Python `features` | Bid/ask → array fitur kausal | Registri deterministik, evaluasi sesuai kebutuhan, cache LRU maksimal 32 seri dependensi untuk dataset. |
| Python `search` | Satu CSV simbol dan spesifikasi biaya → laporan JSON | Seleksi pada train dengan uji blok dan Holm. Satu hari observasi jeda. Walk-forward dan holdout akhir. Riset dalam points pada notional tetap. |
| Python `train` | Quote dan biaya → artefak ensemble dan laporan | Logistic regression, random forest dan histogram gradient boosting. Bobot dari validasi kronologis, log loss dan Brier pada holdout. |

## Batas implementasi dan urutan integrasi

| Kebutuhan | Status v0.1.0 |
| --- | --- |
| Core EA, exporter, kontrol chart | Source tersedia. Kompilasi, lifecycle tester dan akun demo perlu verifikasi MT5. |
| Data subdetik | `OnTick` pada chart utama dan sampling quote terkini melalui timer. Event MT5 dapat digabung. Pemulihan seluruh tick lintas simbol dan integrasi order book masih terbuka. |
| Fitur dan strategi | 5.120 konfigurasi dalam 10 metode dan 245.760 kombinasi dalam dua keluarga strategi. Core MQL5 menjalankan dua strategi dasar tersendiri. Kesetaraan sinyal dan deployment konfigurasi terpilih masih terbuka. |
| Portofolio | Kontrol ukuran, margin, spread, daily equity dan posisi. Korelasi mata uang, fractional Kelly dan batas eksposur per klaster masih terbuka. |
| AI dan promosi | Ensemble offline dan pemeriksaan holdout. Inference MQL5, kalibrasi broker, promotion registry, drift, pipeline otomatis dan rollback masih terbuka. |
| Validasi | Replay, walk-forward, block bootstrap, Holm dan stress biaya tersedia. Data quote asli, spesifikasi sesi/berita, model slippage terukur, audit kualitas dan uji lintas simbol masih diperlukan. |
| Monitoring | Kontrol lokal serta metrik akun, sinyal, posisi, waktu respons dan event maksimum. Dashboard lengkap dan SLA latency masih terbuka. |
| Deployment | Observasi, tester dan demo. Deployment live menunggu seluruh acceptance gate dan persetujuan pemilik. |

Rujukan data dan eksekusi [OnTick](https://www.mql5.com/en/docs/event_handlers/ontick), [OnTradeTransaction](https://www.mql5.com/en/docs/event_handlers/ontradetransaction), [OrderSendAsync](https://www.mql5.com/en/docs/trading/ordersendasync), dan [CopyTicksRange](https://www.mql5.com/en/docs/series/copyticksrange).

## Revisi fondasi V2.0

`Instruments.mqh` memisahkan pembacaan spesifikasi dan pemeriksaan izin entry dari strategi. `HOInstrument` menyimpan snapshot metadata per simbol. Mesin memakai nama broker apa adanya dan membaca izin/sesi lagi sebelum entry. Klasifikasi dari path, mata uang dasar dan mode kalkulasi adalah deskriptif. Klasifikasi yang belum dikenal jatuh ke OTHER.

OnInit memilih satu dari tiga sumber instrumen. Pump menjadwalkan polling bergilir, memperbarui model sinyal dari quote baru, lalu meneruskan kandidat terbaik ke gate risiko. Trade dispatcher mempertahankan satu intent yang belum direkonsiliasi. Kalkulasi risiko dan margin memakai mata uang akun melalui OrderCalcProfit dan OrderCalcMargin. Batas eksposur stop berlaku pada posisi yang teridentifikasi sebagai milik EA. Puncak ekuitas demo disimpan antar restart dan dipakai untuk latch drawdown. Netting tetap konservatif dengan paling banyak satu posisi per simbol dan pemeriksaan kepemilikan sebelum exit demo.

Riset Python membaca ekspor bid/ask dan memproduksi hasil walk-forward serta model offline. Pemindahan kandidat ke EA memerlukan prosedur promosi dan uji broker. Worker C++ membutuhkan baseline latency MT5 dan pengukuran overhead integrasi.
