# Verifikasi fondasi V2.0

| Fase | Bukti dan status |
| --- | --- |
| 1. Arsitektur | Kontrak modul dan alur penerimaan terdokumentasi. |
| 2–4. Discovery, eksekusi dan risiko | Source memakai `_Symbol`, daftar nama persis atau katalog MT5. Gate entry memakai arah, sesi, expiry dan flag order broker. Budget stop risk per strategi, simbol, dan portofolio serta drawdown ekuitas tersedia. Lifecycle request serial, latch dan rekonsiliasi dasar dari EA lama dipertahankan. Build dan uji terminal menunggu MetaEditor. |
| 5–6. Fitur dan kandidat | 10.240 konfigurasi unik dari 10 metode dan 491.520 kombinasi kandidat momentum/reversion. Unik berdasarkan ID konfigurasi. Kausalitas diperiksa dengan fixture. Kandidat merupakan hipotesis. |
| 7–11. Koordinasi, timeframe, AI dan seleksi | Dua strategi dengan pemilihan satu intent per giliran, ensemble Python offline dan seleksi walk-forward dasar tersedia. Agregasi detik, virtual ledger netting, AI di EA, model khusus aset, cross-asset covariance dan lifecycle promosi lengkap masih terbuka. |
| 12–14. Replay, validasi dan benchmark | 11 tes Python lulus. Replay bid/ask, latency, biaya, holdout dan bootstrap diuji secara sintetis. Benchmark terbaru ada di [BENCHMARK_PYTHON.json](BENCHMARK_PYTHON.json). Latency broker, performa pasar dan purged CV penuh belum terverifikasi. |
| 15–17. Operasional | Source menyediakan mode observasi, tester dan demo. Uji demo broker, validasi forward, otorisasi live dan monitoring operasional belum dilakukan. |

Kompilasi MQL5 dan penerbitan EX5 membutuhkan MetaEditor. Paket berisi source, skrip kompilasi Windows dan skrip pembacaan spesifikasi broker. Bukti penerimaan meliputi log kompilasi dan hasil matriks di [MT5.md](MT5.md). Batas risiko adalah estimasi berdasarkan stop, spread dan buffer. Gap harga, komisi, perubahan konversi, atau penolakan broker dapat mengubah kerugian aktual.
