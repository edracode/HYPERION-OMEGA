# VE-HYPERION OMEGA V2.0 — fondasi multi-aset

Fondasi Expert Advisor MT5 untuk eksperimen scalping multi-simbol dan pipeline riset kuantitatif Python. Baca [arsitektur](docs/ARCHITECTURE.md) dan [prosedur verifikasi MT5](docs/MT5.md) sebelum menjalankan mode demo.

| Folder | Isi |
| --- | --- |
| mt5/Experts/HyperionOmega | EA utama dan pustaka sinyal MQL5. |
| mt5/Scripts/HyperionOmega | Eksportir bid/ask dan diagnostik spesifikasi broker. |
| research | Registri fitur, generator kandidat, replay, seleksi dan ensemble offline. |
| config | Profil observasi, Strategy Tester dan demo hedging. |
| tests | Regresi registry, kausalitas, simulasi, statistik, dan AI. |
| scripts | Instalasi sumber dan kompilasi EA/exporter dengan MetaEditor. |
| docs | Arsitektur, verifikasi MT5, dan benchmark komputasi. |

## Memilih simbol di MT5

- Untuk backtest satu simbol, muat `config/Universal-Tester.set`, pilih instrumen pada Strategy Tester dan biarkan `Symbols` kosong.
- Untuk daftar simbol, isi `Symbols` memakai nama persis dari broker, misalnya `EURUSDm,XAUUSDm,BTCUSDm`. Daftar tersebut mengesampingkan `Universe`.
- Untuk observasi katalog, gunakan `config/Broker-Observe.set`. EA memilih instrumen yang lolos pemeriksaan metadata awal dan memeriksa kutipan dalam giliran terbatas. Pemindaian ini bisa menambah simbol ke Market Watch dan memuat histori.

Status penerimaan dan batas yang masih terbuka dicatat di [VERIFICATION.md](docs/VERIFICATION.md).

## Instalasi riset

Python 3.12 direkomendasikan. Setelah membuat virtual environment, aktifkan dan jalankan perintah dari root proyek.

~~~bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
~~~

Untuk Windows, aktifkan virtual environment melalui `.venv\Scripts\Activate.ps1`. CSV harus memuat `time_msc,bid,ask` untuk satu simbol dengan waktu epoch dalam milidetik dan urutan asli broker, termasuk baris dengan timestamp sama. Hari dihitung dari tanggal UTC yang memiliki observasi. Catat sumber, simbol, rentang, dan biaya.

~~~bash
python -m research.search EURUSD.csv --output walk-forward.json \
  --point 0.00001 --commission 7 --slippage 1.5 --financing 10 \
  --max-spread 20 --budget 256 --data-origin "Isi broker, simbol, akun, dan periode ekspor"
python -m research.train EURUSD.csv --output ensemble.json \
  --model-output ensemble.joblib --point 0.00001 --round-trip-points 10 \
  --data-origin "Isi broker, simbol, akun, dan periode ekspor"
python -m research.benchmark benchmark-local.json
~~~

Nilai biaya di atas adalah contoh satuan CLI. Konversikan komisi broker menjadi points pada notional riset. Replay menagih spread melalui harga bid/ask yang berbeda, komisi round trip, slippage per sisi, dan estimasi financing per pergantian hari UTC. Stop pasar dapat terisi melewati level saat terjadi gap. Time exit mengevaluasi dampak latency. Kuota `--budget` menentukan jumlah kandidat yang diuji per seleksi. Drawdown akun, margin, dan gabungan portofolio perlu diuji di MT5.

Hasil walk-forward adalah kinerja proses seleksi di periode bergulir. Kandidat akhir dipilih dengan jendela train sebelum holdout terakhir. Bekukan holdout sebelum membaca hasil dan sebelum mengubah strategi. Uji t untuk blok lima hari adalah aproksimasi dengan daya uji terbatas. Estimasi ketidakpastian bootstrap bersyarat pada data yang digunakan. Laporan `ensemble.json` menilai peluang pergerakan naik yang cukup untuk menutup ambang biaya pada horizon tertentu. Muat artefak `.joblib` hanya dari pipeline pelatihan yang dipercaya.
