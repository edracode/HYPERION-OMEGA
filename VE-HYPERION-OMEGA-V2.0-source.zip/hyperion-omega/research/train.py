"""Fit an offline probabilistic ensemble using ordered, purged UTC-day splits."""
import argparse
import hashlib
import json
from pathlib import Path

from joblib import dump
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss, log_loss
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

from .features import PRICE_METHODS, Feature, FeatureEngine
from .replay import DAY_MS, Quotes


FEATURES = tuple(Feature(name, a, b) for name in PRICE_METHODS for a, b in ((8, 40), (16, 64)))


def make_samples(q, horizon_ms, round_trip_points):
    engine = FeatureEngine(q.bid, q.ask, q.point)
    raw = np.column_stack([engine.compute(f) for f in FEATURES])
    exit_idx = np.searchsorted(q.time, q.time + horizon_ms)
    safe = np.minimum(exit_idx, len(q.time) - 1)
    day = q.time // DAY_MS
    valid = ((exit_idx < len(q.time)) & (q.time[safe] - q.time < horizon_ms * 2)
             & (day == day[safe]) & np.isfinite(raw).all(axis=1))
    # This supervised event measures bid-over-ask move at the research horizon.
    y = (q.bid_points[safe] - q.ask_points) > round_trip_points
    return raw[valid], y[valid], day[valid]


def evaluate(y, proba):
    return {"samples": int(len(y)), "positive_fraction": float(np.mean(y)),
            "log_loss": float(log_loss(y, proba, labels=[False, True])),
            "brier": float(brier_score_loss(y, proba))}


def train(q, horizon_ms, round_trip_points):
    x, y, date = make_samples(q, horizon_ms, round_trip_points)
    days = np.unique(date)
    if len(days) < 15:
        raise ValueError("Need at least 15 UTC days with valid labeled samples")
    val_start, test_start = len(days) * 3 // 5, len(days) * 4 // 5
    train_rows = date < days[val_start - 1]
    val_rows = (date >= days[val_start]) & (date < days[test_start - 1])
    test_rows = date >= days[test_start]
    if any(rows.sum() < 100 or np.unique(y[rows]).size != 2 for rows in (train_rows, val_rows, test_rows)):
        raise ValueError("Each split needs at least 100 labeled records with both outcomes")
    models = {
        "logistic": make_pipeline(StandardScaler(), LogisticRegression(max_iter=300, random_state=1729)),
        "random_forest": RandomForestClassifier(n_estimators=100, max_depth=8, min_samples_leaf=30,
                                                random_state=1729, n_jobs=1),
        "hist_gradient_boosting": HistGradientBoostingClassifier(max_iter=90, max_leaf_nodes=15,
                                                                 early_stopping=False, random_state=1729),
    }
    baseline = float(y[train_rows].mean())
    with threadpool_limits(limits=1):
        # Fit weights from validation only. The baseline acts as a candidate with its own probability.
        validation = {"prior": evaluate(y[val_rows], np.full(val_rows.sum(), baseline))}
        predictions = {"prior": np.full(test_rows.sum(), baseline)}
        for name, model in models.items():
            model.fit(x[train_rows], y[train_rows])
            validation[name] = evaluate(y[val_rows], model.predict_proba(x[val_rows])[:, 1])
            predictions[name] = model.predict_proba(x[test_rows])[:, 1]
    raw = {name: np.exp(-5 * result["log_loss"]) for name, result in validation.items()}
    weights = {name: float(score / sum(raw.values())) for name, score in raw.items()}
    combined = sum(weights[name] * proba for name, proba in predictions.items())
    report = {"horizon_ms": horizon_ms, "round_trip_points": round_trip_points,
              "validation": validation, "weights": weights,
              "test": {name: evaluate(y[test_rows], prob) for name, prob in predictions.items()},
              "test_ensemble": evaluate(y[test_rows], combined), "test_utc_day_start": int(days[test_start]),
              "feature_ids": [f.id for f in FEATURES]}
    report["beats_prior_on_holdout"] = all(
        report["test_ensemble"][m] < report["test"]["prior"][m] for m in ("log_loss", "brier"))
    return {"models": models, "baseline": baseline, "report": report}, report


def cli():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("csv", type=Path)
    p.add_argument("--point", type=float, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--model-output", type=Path, required=True)
    p.add_argument("--horizon-ms", type=int, default=15_000)
    p.add_argument("--round-trip-points", type=float, required=True)
    p.add_argument("--data-origin", required=True)
    args = p.parse_args()
    if (args.horizon_ms < 1000 or args.horizon_ms > 300_000 or args.round_trip_points < 0
            or not np.isfinite(args.round_trip_points)
            or len({path.resolve() for path in (args.csv, args.output, args.model_output)}) != 3):
        p.error("Check horizon, costs and distinct input/output paths")
    bundle, report = train(Quotes.read(args.csv, args.point), args.horizon_ms, args.round_trip_points)
    with args.csv.open("rb") as f:
        report["quotes"] = {"sha256": hashlib.file_digest(f, "sha256").hexdigest(), "origin": args.data_origin}
    dump(bundle, args.model_output)
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    cli()
