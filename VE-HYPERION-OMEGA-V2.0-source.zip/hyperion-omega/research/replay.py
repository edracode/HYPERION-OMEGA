"""Causal single-position quote replay in points at a fixed notional."""
from dataclasses import dataclass
from functools import cached_property
from pathlib import Path

import numpy as np
import pandas as pd


DAY_MS = 86_400_000


@dataclass(frozen=True)
class Quotes:
    time: np.ndarray
    bid: np.ndarray
    ask: np.ndarray
    point: float

    @cached_property
    def bid_points(self):
        return self.bid / self.point

    @cached_property
    def ask_points(self):
        return self.ask / self.point

    @classmethod
    def read(cls, path: Path, point: float):
        table = pd.read_csv(path, usecols=["time_msc", "bid", "ask"])
        if not np.isfinite(point) or point <= 0 or len(table) < 2:
            raise ValueError("A positive point and at least two quotes are required")
        time = table["time_msc"].to_numpy()
        bid = table["bid"].to_numpy(dtype=float)
        ask = table["ask"].to_numpy(dtype=float)
        if (time.dtype.kind not in "iu" or (time <= 0).any() or (time[1:] < time[:-1]).any()
                or (time >= np.iinfo(np.int64).max - DAY_MS).any()
                or not np.isfinite(bid).all() or not np.isfinite(ask).all()
                or (bid <= 0).any() or (ask < bid).any()):
            raise ValueError("Invalid timestamps or bid/ask quotes")
        return cls(time.astype(np.int64, copy=False), bid, ask, point)


@dataclass(frozen=True)
class Costs:
    commission: float
    slippage: float
    latency_ms: int
    max_spread: float
    max_fill_delay_ms: int
    financing: float


@dataclass(frozen=True)
class Trade:
    opened_ms: int
    closed_ms: int
    side: int
    net_points: float
    reason: str


def replay(q: Quotes, signals: np.ndarray, start: int, end: int, costs: Costs,
           hold_ms: int, stop: float, take: float) -> list[Trade]:
    trades = []
    time, bid, ask = q.time, q.bid_points, q.ask_points
    i = start
    while i < end - 1:
        side = int(signals[i])
        if not side or ask[i] - bid[i] > costs.max_spread:
            i += 1
            continue
        # At least one subsequent record is required, even with zero latency.
        entry_index = max(i + 1, int(time.searchsorted(time[i] + costs.latency_ms)))
        if entry_index >= end - 1:
            break
        if (time[entry_index] - time[i] > costs.max_fill_delay_ms
                or ask[entry_index] - bid[entry_index] > costs.max_spread
                or time[entry_index] // DAY_MS != time[i] // DAY_MS):
            i = entry_index
            continue
        entry = (ask[entry_index] if side > 0 else bid[entry_index]) + side * costs.slippage
        j = entry_index + 1
        while j < end:
            current = bid[j] if side > 0 else ask[j]
            gross = (current - entry) * side
            if gross <= -stop:
                reason = "stop"
                break
            if gross >= take:
                gross = take
                reason = "target"
                break
            if time[j] - time[entry_index] >= hold_ms:
                reason = "time"
                break
            j += 1
        if j == end:
            j = end - 1
            gross = ((bid[j] if side > 0 else ask[j]) - entry) * side
            reason = "boundary"
        elif reason == "time":
            delayed = max(j, min(end - 1, int(time.searchsorted(time[j] + costs.latency_ms))))
            # Server-side stops remain effective while the close request is in transit.
            for k in range(j + 1, delayed + 1):
                gross = ((bid[k] if side > 0 else ask[k]) - entry) * side
                if gross <= -stop or gross >= take:
                    reason = "stop" if gross <= -stop else "target"
                    gross = min(gross, take)
                    delayed = k
                    break
            j = delayed
        financing_days = time[j] // DAY_MS - time[entry_index] // DAY_MS
        pnl = gross - costs.slippage - costs.commission - financing_days * costs.financing
        trades.append(Trade(int(time[entry_index]), int(time[j]), side, float(pnl), reason))
        i = j + 1
    return trades
