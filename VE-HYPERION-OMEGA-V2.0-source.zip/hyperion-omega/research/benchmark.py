"""Measure feature calculation and replay on a deterministic software fixture."""
import argparse
import json
import platform
from pathlib import Path
from time import perf_counter_ns

import numpy as np

from .features import FeatureEngine, feature_registry
from .replay import Costs, Quotes, replay
from .search import candidates, signal


def benchmark(ticks, candidate_count):
    rng = np.random.default_rng(20261121)
    time = 1_735_689_600_000 + np.arange(ticks) * 125
    bid = 1.1 + np.cumsum(rng.normal(0, 1e-5, ticks))
    q = Quotes(time, bid, bid + rng.uniform(1e-5, 4e-5, ticks), 1e-5)
    engine = FeatureEngine(q.bid, q.ask, q.point)
    costs = Costs(.6, .25, 75, 10, 1000, 0)
    grid = list(candidates(feature_registry()))
    if not 1 <= candidate_count <= len(grid):
        raise ValueError(f"candidate_count must be within 1..{len(grid)}")
    feature_ms, replay_ms = [], []
    for i in range(candidate_count):
        c = grid[i * len(grid) // candidate_count]
        start = perf_counter_ns()
        values = engine.compute(c.feature)
        computed = perf_counter_ns()
        replay(q, signal(values, c), 0, ticks, costs, c.hold * 1000, c.stop, c.take)
        end = perf_counter_ns()
        feature_ms.append((computed - start) / 1e6)
        replay_ms.append((end - computed) / 1e6)

    def summary(samples):
        return {f"p{q}": float(np.percentile(samples, q)) for q in (50, 95, 99)}

    try:
        import resource
    except ImportError:
        peak_rss = None
    else:
        scale = 1 if platform.system() == "Darwin" else 1024
        peak_rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * scale

    return {"data": "synthetic_software_fixture", "platform": platform.platform(),
            "python": platform.python_version(), "numpy": np.__version__,
            "ticks": ticks, "candidates": candidate_count,
            "feature_array_compute_ms": summary(feature_ms), "signal_and_replay_ms": summary(replay_ms),
            "process_peak_rss_bytes": peak_rss}


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("output", type=Path)
    cli.add_argument("--ticks", type=int, default=20_000)
    cli.add_argument("--candidates", type=int, default=60)
    args = cli.parse_args()
    if args.ticks < 1000:
        cli.error("Require at least 1000 quotes")
    try:
        result = benchmark(args.ticks, args.candidates)
    except ValueError as exc:
        cli.error(str(exc))
    args.output.write_text(json.dumps(result, indent=2) + "\n")
