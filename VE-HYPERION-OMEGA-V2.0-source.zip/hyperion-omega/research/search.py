"""Walk-forward selection, multiplicity control and a separate terminal holdout."""
import argparse
import hashlib
import json
from dataclasses import asdict, dataclass, replace
from itertools import product
from pathlib import Path
import time

import numpy as np
from scipy.stats import t as student_t

from .features import Feature, FeatureEngine, feature_registry
from .replay import Costs, DAY_MS, Quotes, Trade, replay


@dataclass(frozen=True)
class Candidate:
    feature: Feature
    style: str
    threshold: float
    hold: int
    stop: float
    take: float

    @property
    def id(self):
        f = self.feature.id
        return f"{f}/{self.style}/{self.threshold:g}/{self.hold}/{self.stop:g}/{self.take:g}"


def candidates(registry, hold_times=(5, 15, 30, 60, 180, 300)):
    for feature in registry:
        for style, threshold, hold, bracket in product(
            ("momentum", "reversion"), (1.5, 3.0), hold_times, ((40, 50), (80, 95))
        ):
            yield Candidate(feature, style, threshold, hold, *bracket)


def daily_pnl(trades: list[Trade], days: np.ndarray):
    points = np.zeros(len(days))
    for tx in trades:
        i = int(days.searchsorted(tx.closed_ms // DAY_MS))
        if i >= len(days) or days[i] != tx.closed_ms // DAY_MS:
            raise ValueError("Trade closes outside evaluation days")
        points[i] += tx.net_points
    return points


def metrics(trades: list[Trade], days: np.ndarray, bootstrap=False):
    pnl = np.array([tx.net_points for tx in trades])
    daily = daily_pnl(trades, days)
    curve = np.r_[0.0, pnl.cumsum()]
    gains = pnl[pnl > 0].sum()
    losses = -pnl[pnl < 0].sum()
    sd = daily.std(ddof=1) if len(daily) > 1 else 0.0
    downside = np.sqrt(np.mean(np.minimum(daily, 0.0)**2))
    drawdown = (np.maximum.accumulate(curve) - curve).max()
    result = {"trades": int(len(pnl)), "net_points": float(pnl.sum()),
              "mean_net_points": float(pnl.mean()) if len(pnl) else None,
              "profit_factor": float(gains / losses) if losses else None,
              "daily_sharpe_252": float(np.sqrt(252) * daily.mean() / sd) if sd else None,
              "daily_sortino_252": float(np.sqrt(252) * daily.mean() / downside) if downside else None,
              "max_drawdown_points": float(drawdown),
              "recovery_factor": float(pnl.sum() / drawdown) if drawdown else None,
              "win_rate": float((pnl > 0).mean()) if len(pnl) else None,
              "avg_hold_seconds": float(np.mean([tx.closed_ms - tx.opened_ms for tx in trades]) / 1_000)
              if trades else None,
              "largest_winner_fraction": float(pnl.max() / gains) if gains else None}
    if bootstrap:
        result["daily_block_bootstrap"] = block_bootstrap(daily)
    return result


def block_bootstrap(daily, trials=1000, block=5):
    if len(daily) < 2 * block:
        return None
    rng = np.random.default_rng(1729)
    starts = rng.integers(0, len(daily), (trials, (len(daily) + block - 1) // block))
    paths = daily[((starts[..., None] + np.arange(block)) % len(daily)).reshape(trials, -1)[:, :len(daily)]]
    totals = paths.sum(axis=1)
    curves = np.column_stack((np.zeros(trials), paths.cumsum(axis=1)))
    drawdowns = (np.maximum.accumulate(curves, axis=1) - curves).max(axis=1)
    return {"block_days": block, "trials": trials, "net_points_95_interval": np.quantile(totals, [.025, .975]).tolist(),
            "drawdown_points_p95": float(np.quantile(drawdowns, .95))}


def block_pvalue(daily, block=5):
    n = len(daily) // block
    if n < 4:
        return 1.0
    blocks = daily[-n * block:].reshape(n, block).sum(axis=1)
    sd = blocks.std(ddof=1)
    return float(student_t.sf(np.sqrt(n) * blocks.mean() / sd, n - 1)) if sd > 0 else 1.0


def holm(pvalues, alpha=.05):
    selected = []
    for rank, (key, pvalue) in enumerate(sorted(pvalues.items(), key=lambda item: item[1])):
        if pvalue > alpha / (len(pvalues) - rank):
            break
        selected.append(key)
    return selected


def signal(values, candidate):
    direction = 1 if candidate.style == "momentum" else -1
    return np.select((values >= candidate.threshold, values <= -candidate.threshold),
                     (direction, -direction), default=0)


def run(q, costs, budget, train_days, test_days, holdout_days):
    began = time.perf_counter()
    days = np.unique(q.time // DAY_MS)
    first = train_days + 1  # A full observed UTC day separates training and validation.
    if len(days) < first + test_days + holdout_days:
        raise ValueError(f"Need >= {first + test_days + holdout_days} observed UTC days")
    registry = feature_registry()
    # Round robin across feature methods before exploring further parameter combinations.
    count_per_method = len(registry) // 10
    registry = tuple(registry[method * count_per_method + offset]
                     for offset in range(count_per_method) for method in range(10))
    grid = list(candidates(registry))
    # Sample the complete grid at deterministic equal strides when compute budget is limited.
    chosen = [grid[i * len(grid) // budget] for i in range(budget)]
    engine = FeatureEngine(q.bid, q.ask, q.point)

    def evaluate(c, start, end, model_costs, raw=None):
        a = int(q.time.searchsorted(days[start] * DAY_MS))
        b = int(q.time.searchsorted(days[end] * DAY_MS)) if end < len(days) else len(q.time)
        if raw is None:
            raw = engine.compute(c.feature)
        return replay(q, signal(raw, c), a, b, model_costs, c.hold * 1000, c.stop, c.take)

    def select(end_train):
        begin_train = end_train - train_days
        used_days = days[begin_train:end_train]
        pvalues, scores = {}, {}
        last_feature, raw = None, None
        for c in chosen:
            if c.feature != last_feature:
                raw = engine.compute(c.feature)
                last_feature = c.feature
            trades = evaluate(c, begin_train, end_train, costs, raw)
            points = daily_pnl(trades, used_days)
            pvalues[c] = block_pvalue(points) if len(trades) >= 30 else 1.0
            scores[c] = float(points.sum())
        passed = holm(pvalues)
        winner = max(passed, key=lambda c: scores[c], default=None)
        return winner, len(passed), min(pvalues.values())

    stressed = replace(costs, commission=costs.commission * 1.5, slippage=costs.slippage * 2,
                       latency_ms=min(costs.latency_ms * 2, costs.max_fill_delay_ms), financing=costs.financing * 1.5)
    before_holdout = len(days) - holdout_days
    walk = []
    for start in range(first, before_holdout - test_days + 1, test_days):
        winner, count, min_p = select(start - 1)
        end = start + test_days
        out = evaluate(winner, start, end, costs) if winner else []
        walk.append({"first_utc_day": int(days[start]), "candidate": winner.id if winner else None,
                     "passed_holm": count, "training_min_unadjusted_p": min_p,
                     "metrics": metrics(out, days[start:end])})
    winner, count, min_p = select(before_holdout - 1)
    final, stress, sensitivity = [], [], {}
    if winner:
        final = evaluate(winner, before_holdout, len(days), costs)
        stress = evaluate(winner, before_holdout, len(days), stressed)
        for scale in (.9, 1.1):
            neighbor = replace(winner, threshold=winner.threshold * scale)
            sample = evaluate(neighbor, before_holdout, len(days), costs)
            sensitivity[str(scale)] = metrics(sample, days[before_holdout:])
    oos = metrics(final, days[before_holdout:], bootstrap=True)
    stressed_metrics = metrics(stress, days[before_holdout:])
    checks = {
        "positive_expectancy": (oos["mean_net_points"] or 0) > 0,
        "profit_factor_above_1_30": (oos["profit_factor"] or 0) > 1.30,
        "daily_sharpe_above_1_50": (oos["daily_sharpe_252"] or 0) > 1.50,
        "positive_stress": stressed_metrics["net_points"] > 0,
        "stable_neighbors": bool(sensitivity) and all(m["net_points"] > 0 for m in sensitivity.values()),
        "at_least_30_oos_trades": oos["trades"] >= 30,
        "positive_bootstrap_lower_bound": bool(oos["daily_block_bootstrap"]) and
        oos["daily_block_bootstrap"]["net_points_95_interval"][0] > 0,
        "no_concentration": oos["largest_winner_fraction"] is not None and oos["largest_winner_fraction"] <= .25,
        "positive_multiple_walk_forward_windows": sum(row["metrics"]["net_points"] > 0 for row in walk) >= 2,
    }
    return {"features_registered": len(registry), "candidates_generated": len(grid), "candidates_per_selection": budget,
            "costs": asdict(costs), "stress_costs": asdict(stressed), "walk_forward": walk,
            "holdout": {"days": holdout_days, "first_utc_day": int(days[before_holdout]),
                        "candidate": winner.id if winner else None,
                        "passed_holm": count, "training_min_unadjusted_p": min_p,
                        "metrics": oos, "stressed": stressed_metrics,
                        "threshold_sensitivity": sensitivity},
            "research_checks": checks, "research_checks_passed": all(checks.values()),
            "promotion": "blocked_pending_broker_demo_and_approved_drawdown_limit",
            "elapsed_seconds": time.perf_counter() - began}


def cli():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("csv", type=Path)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--point", type=float, required=True)
    p.add_argument("--commission", type=float, required=True, help="Round-trip commission in points")
    p.add_argument("--slippage", type=float, required=True, help="Adverse slippage per side in points")
    p.add_argument("--financing", type=float, required=True, help="Adverse financing in points per UTC day boundary crossed")
    p.add_argument("--latency-ms", type=int, default=50)
    p.add_argument("--max-fill-delay-ms", type=int, default=1000)
    p.add_argument("--max-spread", type=float, required=True, help="Max entry spread in points")
    p.add_argument("--budget", type=int, default=256)
    p.add_argument("--train-days", type=int, default=40)
    p.add_argument("--test-days", type=int, default=10)
    p.add_argument("--holdout-days", type=int, default=20)
    p.add_argument("--data-origin", required=True, help="Broker/source, symbol, and export profile")
    args = p.parse_args()
    costs = Costs(args.commission, args.slippage, args.latency_ms, args.max_spread,
                  args.max_fill_delay_ms, args.financing)
    numbers = (costs.commission, costs.slippage, costs.max_spread, costs.financing)
    if (not all(np.isfinite(numbers)) or min(numbers) < 0 or costs.max_spread <= 0
            or costs.latency_ms < 0 or costs.max_fill_delay_ms < max(1, costs.latency_ms)
            or not 1 <= args.budget <= len(feature_registry()) * 48
            or args.train_days < 20 or args.test_days < 1 or args.holdout_days < 10
            or args.csv.resolve() == args.output.resolve()):
        p.error("Invalid cost, sample window or candidate budget")
    quotes = Quotes.read(args.csv, args.point)
    report = run(quotes, costs, args.budget, args.train_days, args.test_days, args.holdout_days)
    with args.csv.open("rb") as f:
        digest = hashlib.file_digest(f, "sha256").hexdigest()
    report["quotes"] = {"count": len(quotes.time), "point": quotes.point, "origin": args.data_origin, "sha256": digest}
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    cli()
