#property strict
#property script_show_inputs
#include "..\..\Experts\HyperionOmega\Instruments.mqh"

input string InspectSymbol=""; // Empty uses the chart symbol.

void OnStart()
{
   string symbol=InspectSymbol=="" ? _Symbol : InspectSymbol;
   bool custom=false;
   HOInstrument spec;
   if(!SymbolExist(symbol,custom) || !SymbolSelect(symbol,true) || !LoadInstrument(symbol,spec))
   {
      Print("HO INSPECT FAIL: cannot read symbol specification for ",symbol);
      return;
   }
   MqlTick tick={};
   bool quote=SymbolInfoTick(symbol,tick) && tick.time_msc>0 && tick.bid>0 && tick.ask>=tick.bid;
   PrintFormat("HO INSPECT symbol=%s custom=%d class=%s server=%s synchronized=%d bid=%g ask=%g quote=%d",
               symbol,(int)custom,EnumToString(spec.asset),AccountInfoString(ACCOUNT_SERVER),
               (int)SymbolIsSynchronized(symbol),tick.bid,tick.ask,(int)quote);
   PrintFormat("HO SPEC path=%s calculation=%d trade=%d execution=%d filling=%d orders=%d stops=%d freeze=%d",
               spec.path,(int)spec.calculation,(int)spec.trade_mode,(int)spec.execution,
               (int)spec.filling,(int)spec.order_flags,(int)spec.stops,(int)spec.freeze);
   PrintFormat("HO LOT contract=%g tick_size=%g tick_value=%g min=%g max=%g step=%g margin=%g maintenance=%g",
               spec.contract,spec.tick_size,spec.tick_value,spec.min_lot,spec.max_lot,
               spec.lot_step,spec.initial_margin,spec.maintenance_margin);
   datetime now=TimeTradeServer();
   PrintFormat("HO TIME account=%s base=%s profit=%s margin=%s start=%s expiry=%s open=%d",
               AccountInfoString(ACCOUNT_CURRENCY),spec.base,spec.profit_currency,spec.margin_currency,
               TimeToString(spec.starts),TimeToString(spec.expires),(int)InTradeSession(symbol,now));
   for(int day=0;day<7;day++)
   {
      for(uint index=0;index<64;index++)
      {
         datetime from=0, until=0;
         if(!SymbolInfoSessionTrade(symbol,(ENUM_DAY_OF_WEEK)day,index,from,until))
            break;
         PrintFormat("HO SESSION day=%d index=%u start_seconds=%I64d end_seconds=%I64d",
                     day,index,(long)from,(long)until);
      }
   }
   if(!quote)
      return;
   double margin=0, loss=0;
   if(!OrderCalcMargin(ORDER_TYPE_BUY,symbol,spec.min_lot,tick.ask,margin) ||
      !OrderCalcProfit(ORDER_TYPE_BUY,symbol,spec.min_lot,tick.ask,
                       tick.bid-spec.tick_size,loss))
   {
      Print("HO INSPECT FAIL: account-currency buy preview unavailable, error ",GetLastError());
      return;
   }
   PrintFormat("HO BUY PREVIEW margin=%g pnl_one_tick_below_bid=%g",margin,loss);
}
