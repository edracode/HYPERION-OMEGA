#property strict
#property script_show_inputs
input string ExportSymbol="";
input datetime From=D'2025.01.06 00:00';
input datetime Until=D'2025.01.07 00:00';
input string OutputName="hyperion_ticks.csv";

void OnStart()
{
   string symbol=ExportSymbol=="" ? _Symbol : ExportSymbol;
   if(From<=0 || Until<=From || !SymbolSelect(symbol,true))
   {
      Print("Invalid export range or symbol");
      return;
   }
   string partial=OutputName+".partial";
   int file=FileOpen(partial,FILE_WRITE|FILE_CSV|FILE_ANSI,',',CP_UTF8);
   if(file==INVALID_HANDLE)
   {
      Print("Could not open output: ",GetLastError());
      return;
   }
   bool ok=FileWrite(file,"time_msc","bid","ask")>0;
   ulong first=(ulong)From*1000;
   ulong limit=(ulong)Until*1000;
   int digits=(int)SymbolInfoInteger(symbol,SYMBOL_DIGITS);
   long total=0;
   MqlTick ticks[];
   while(first<limit && ok && !IsStopped())
   {
      ulong edge=first+3600000;
      if(edge>limit)
         edge=limit;
      ResetLastError();
      int n=CopyTicksRange(symbol,ticks,COPY_TICKS_INFO,first,edge-1);
      int error=GetLastError();
      if(n<0 || error!=0)
      {
         PrintFormat("Tick history failed at %I64u, code %d",first,error);
         ok=false;
         break;
      }
      for(int i=0;i<n && ok && !IsStopped();i++)
      {
         if(ticks[i].bid<=0 || ticks[i].ask<ticks[i].bid)
            continue;
         ok=FileWrite(file,ticks[i].time_msc,DoubleToString(ticks[i].bid,digits),
                      DoubleToString(ticks[i].ask,digits))>0;
         if(ok)
            total++;
      }
      first=edge;
   }
   FileClose(file);
   if(ok && !IsStopped() && total>0 && FileMove(partial,0,OutputName,FILE_REWRITE))
      PrintFormat("Exported %I64d quote updates for %s into %s",total,symbol,OutputName);
   else
      PrintFormat("Export incomplete for %s: %I64d valid rows. Check partial file and Journal.",symbol,total);
}
