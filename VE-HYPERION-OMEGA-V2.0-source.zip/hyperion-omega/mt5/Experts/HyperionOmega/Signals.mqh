#ifndef HYPERION_SIGNALS
#define HYPERION_SIGNALS

#define HO_STRATEGIES 2

struct HOFeatures
{
   bool ready;
   double previous_mid;
   double fast;
   double slow;
   double movement;
   int observations;
};

void UpdateFeatures(HOFeatures &f,const double mid)
{
   if(!f.ready)
   {
      f.ready=true;
      f.previous_mid=mid;
      f.fast=mid;
      f.slow=mid;
      return;
   }
   f.fast+=2.0/9.0*(mid-f.fast);
   f.slow+=2.0/33.0*(mid-f.slow);
   f.movement+=2.0/33.0*(MathAbs(mid-f.previous_mid)-f.movement);
   f.previous_mid=mid;
   if(f.observations<1000)
      f.observations++;
}

void EvaluateSignals(const HOFeatures &f,const double mid,const double spread,
                     const double cost_buffer, double &scores[])
{
   scores[0]=0;
   scores[1]=0;
   if(f.observations<96 || f.movement<=0)
      return;
   // Scores express a research heuristic in price units.
   double trend=f.fast-f.slow;
   double residual=mid-f.slow;
   if(MathAbs(trend)>=2.5*f.movement && MathAbs(trend)>spread+cost_buffer)
      scores[0]=trend;
   if(MathAbs(trend)<=1.4*f.movement && MathAbs(residual)>=3.0*f.movement &&
      MathAbs(residual)>spread+cost_buffer)
      scores[1]=-residual;
}
#endif
