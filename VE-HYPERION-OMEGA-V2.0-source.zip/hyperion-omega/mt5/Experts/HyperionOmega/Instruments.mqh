#ifndef HYPERION_INSTRUMENTS
#define HYPERION_INSTRUMENTS

enum HOUniverse { HO_CHART, HO_EXPLICIT, HO_BROKER };
enum HOAsset { HO_OTHER, HO_FOREX, HO_METAL, HO_CRYPTO, HO_INDEX, HO_ENERGY };

struct HOInstrument
{
   HOAsset asset;
   string path, base, profit_currency, margin_currency;
   long calculation, execution, filling, stops, freeze, order_flags, trade_mode;
   double point, tick_size, tick_value, contract, min_lot, max_lot, lot_step;
   double initial_margin, maintenance_margin;
   datetime starts, expires;
};

HOAsset ClassifyInstrument(const HOInstrument &p)
{
   string path=p.path;
   StringToLower(path);
   if(p.base=="XAU" || p.base=="XAG" || p.base=="XPT" || p.base=="XPD" ||
      StringFind(path,"metal")>=0)
      return HO_METAL;
   if(StringFind(path,"crypto")>=0 || p.base=="BTC" || p.base=="ETH")
      return HO_CRYPTO;
   if(p.calculation==SYMBOL_CALC_MODE_CFDINDEX || StringFind(path,"indices")>=0 ||
      StringFind(path,"index")>=0)
      return HO_INDEX;
   if(StringFind(path,"energy")>=0 || StringFind(path,"oil")>=0)
      return HO_ENERGY;
   if(p.calculation==SYMBOL_CALC_MODE_FOREX || p.calculation==SYMBOL_CALC_MODE_FOREX_NO_LEVERAGE)
      return HO_FOREX;
   return HO_OTHER;
}

bool LoadInstrument(const string name, HOInstrument &p)
{
   if(!SymbolInfoInteger(name,SYMBOL_TRADE_MODE,p.trade_mode))
      return false;
   p.path=SymbolInfoString(name,SYMBOL_PATH);
   p.base=SymbolInfoString(name,SYMBOL_CURRENCY_BASE);
   p.profit_currency=SymbolInfoString(name,SYMBOL_CURRENCY_PROFIT);
   p.margin_currency=SymbolInfoString(name,SYMBOL_CURRENCY_MARGIN);
   p.calculation=SymbolInfoInteger(name,SYMBOL_TRADE_CALC_MODE);
   p.execution=SymbolInfoInteger(name,SYMBOL_TRADE_EXEMODE);
   p.filling=SymbolInfoInteger(name,SYMBOL_FILLING_MODE);
   p.stops=SymbolInfoInteger(name,SYMBOL_TRADE_STOPS_LEVEL);
   p.freeze=SymbolInfoInteger(name,SYMBOL_TRADE_FREEZE_LEVEL);
   p.order_flags=SymbolInfoInteger(name,SYMBOL_ORDER_MODE);
   p.starts=(datetime)SymbolInfoInteger(name,SYMBOL_START_TIME);
   p.expires=(datetime)SymbolInfoInteger(name,SYMBOL_EXPIRATION_TIME);
   p.point=SymbolInfoDouble(name,SYMBOL_POINT);
   p.tick_size=SymbolInfoDouble(name,SYMBOL_TRADE_TICK_SIZE);
   p.tick_value=SymbolInfoDouble(name,SYMBOL_TRADE_TICK_VALUE);
   p.contract=SymbolInfoDouble(name,SYMBOL_TRADE_CONTRACT_SIZE);
   p.min_lot=SymbolInfoDouble(name,SYMBOL_VOLUME_MIN);
   p.max_lot=SymbolInfoDouble(name,SYMBOL_VOLUME_MAX);
   p.lot_step=SymbolInfoDouble(name,SYMBOL_VOLUME_STEP);
   p.initial_margin=SymbolInfoDouble(name,SYMBOL_MARGIN_INITIAL);
   p.maintenance_margin=SymbolInfoDouble(name,SYMBOL_MARGIN_MAINTENANCE);
   p.asset=ClassifyInstrument(p);
   return p.point>0 && p.tick_size>0 && p.contract>0 && p.min_lot>0 &&
          p.max_lot>=p.min_lot && p.lot_step>0;
}

bool EntryTradeMode(const long mode,const bool buy)
{
   return mode==SYMBOL_TRADE_MODE_FULL ||
          (buy && mode==SYMBOL_TRADE_MODE_LONGONLY) ||
          (!buy && mode==SYMBOL_TRADE_MODE_SHORTONLY);
}

bool InTradeSession(const string symbol,const datetime now)
{
   MqlDateTime clock={};
   if(now<=0 || !TimeToStruct(now,clock))
      return false;
   int seconds=clock.hour*3600+clock.min*60+clock.sec;
   for(int offset=0;offset<=1;offset++)
   {
      ENUM_DAY_OF_WEEK day=(ENUM_DAY_OF_WEEK)((clock.day_of_week+7-offset)%7);
      for(uint index=0;index<64;index++)
      {
         datetime from=0, until=0;
         if(!SymbolInfoSessionTrade(symbol,day,index,from,until))
            break;
         long start=(long)from%86400;
         long end=(long)until;
         if(end<start)
            end+=86400;
         // Midnight as the session endpoint is represented as zero or 86400.
         if(end==0)
            end=86400;
         long elapsed=seconds+86400*offset;
         if(elapsed>=start && elapsed<end)
            return true;
      }
   }
   return false;
}

bool BrokerEntryAvailable(const string symbol,const bool buy,const datetime now)
{
   long mode=0, flags=0;
   if(!SymbolInfoInteger(symbol,SYMBOL_TRADE_MODE,mode) || !EntryTradeMode(mode,buy) ||
      !SymbolInfoInteger(symbol,SYMBOL_ORDER_MODE,flags))
      return false;
   const long required=SYMBOL_ORDER_MARKET | SYMBOL_ORDER_SL | SYMBOL_ORDER_TP;
   if((flags & required)!=required)
      return false;
   datetime starts=(datetime)SymbolInfoInteger(symbol,SYMBOL_START_TIME);
   datetime expires=(datetime)SymbolInfoInteger(symbol,SYMBOL_EXPIRATION_TIME);
   return (starts==0 || now>=starts) && (expires==0 || now<expires) &&
          InTradeSession(symbol,now);
}

#endif
