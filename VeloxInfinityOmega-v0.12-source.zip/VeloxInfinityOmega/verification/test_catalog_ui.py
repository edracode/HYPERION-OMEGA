"""Static integration checks for v0.11; no MT5 runtime is invoked."""
import re
import unittest
from pathlib import Path

SOURCE = (Path(__file__).resolve().parents[1] / "VeloxInfinityOmega.mq5").read_text()

class CatalogDashboardChecks(unittest.TestCase):
    def test_catalog_keeps_native_names(self):
        self.assertIn("SymbolsTotal(false)", SOURCE)
        self.assertIn("SymbolName(syncCursor,false)", SOURCE)
        self.assertIn("RegisterMarket(symbol)", SOURCE)
        self.assertNotRegex(SOURCE, r"input string (Symbols|BrokerPrefix|BrokerSuffix)")
        self.assertNotIn("count>24", SOURCE)

    def test_catalog_scan_wraps_and_prioritizes_owned_symbols(self):
        self.assertIn("scanCursor=(scanCursor+1)%n", SOURCE)
        self.assertIn("RegisterMarket(PositionGetString(POSITION_SYMBOL))", SOURCE)
        self.assertIn("if(scanCatalog && n>0)", SOURCE)
        self.assertIn("void OnTimer(){ Cycle(true); }", SOURCE)

    def test_controls_are_wired(self):
        for control in ("start", "prev", "chart", "next", "gridtoggle", "mode", "basket", "close", "stop"):
            self.assertIn(f'Button("{control}",', SOURCE)
            self.assertIn(f'action=="{control}"', SOURCE)
        self.assertIn("CHARTEVENT_CHART_CHANGE", SOURCE)

    def test_delimiters(self):
        stack = []
        for token in re.sub(r'"[^"\n]*"|//[^\n]*', '', SOURCE):
            if token in "([{":
                stack.append(token)
            elif token in ")]}":
                self.assertTrue(stack)
                self.assertEqual(stack.pop(), {")": "(", "]": "[", "}": "{"}[token])
        self.assertFalse(stack)

if __name__ == "__main__":
    unittest.main(verbosity=2)

class ExposureChecks(unittest.TestCase):
    def test_first_entry_unblocks_only_when_flat(self):
        self.assertIn("MaintainOnePosition && positionCount==0", SOURCE)
        self.assertIn("activeBaskets<MaxBaskets && (NeedsExposure() || rank>=threshold)", SOURCE)
        self.assertIn("rank<threshold || m.side*m.trend<-0.45", SOURCE)
        self.assertIn("if(!CanOpen(m)) return false", SOURCE)

    def test_minimum_lot_still_passes_portfolio_caps(self):
        self.assertIn("sample*unit<=equity*0.01", SOURCE)
        self.assertIn("MathMin(raw,volumeCap)", SOURCE)
        self.assertIn("!OrderCheck(request,check)", SOURCE)
        self.assertIn("stressed<StopoutFloor(margin)", SOURCE)
