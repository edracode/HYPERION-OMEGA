# Velox Infinity Martingale Omega

Milestone rekayasa 0.12 untuk MetaTrader 5. Paket berisi EA native MQL5, panel chart, preset, registri riset offline, dan pemeriksaan referensi Python. EA dibatasi ke Strategy Tester dan akun non-real. Preset memulai pemindaian segera setelah izin Algo Trading tersedia. Saat EA kosong, MaintainOnePosition mencari satu entry dengan skor arah relatif terbaik pada batch yang tersedia dan tetap memakai batas risiko.

| Preset | Risiko awal nominal | Batas basket | Batas agregat | Lapisan | Margin minimum |
|---|---:|---:|---:|---:|---:|
| Survival | 0,35% | 0,90% | 2,50% | 4 | 400% |
| Aggressive Growth | 0,45% | 1,20% | 3,00% | 5 | 375% |
| Experimental Extreme | 0,60% | 1,65% | 4,00% | 6 | 325% |

Faktor profil masing-masing 1,00, 1,25, dan 1,60 diterapkan pada alokasi awal sebelum pemotongan risiko. Tombol Mode mengubah faktor profil dan ambang sinyal saat runtime. Memuat berkas preset turut mengubah seluruh input yang tercantum pada berkas tersebut.

Baca [instalasi](INSTALLATION.md), [arsitektur](STRATEGY_ARCHITECTURE.md), [risiko](RISK_MANAGEMENT.md), dan [panduan backtest](BACKTEST_GUIDE.md).

## Perbaikan v0.12

- Katalog seluruh simbol broker dideteksi otomatis. Nama bersufiks disimpan persis. Kegagalan feed individual dicatat di panel dan diputar kembali pada giliran berikutnya.
- Pemindaian dibagi dalam batch timer. Simbol chart serta posisi yang masih terbuka diprioritaskan. Ukuran batch terpisah dari jumlah maksimum basket bersamaan.
- Panel ungu dan teal memakai kartu metrik, bar drawdown, diagnostik izin dan feed, navigasi simbol, serta tata letak ringkas otomatis.
- Pada Strategy Tester, katalog juga dipindai secara default. Untuk membandingkan performa satu simbol, set `TesterScanAllBrokerSymbols=false`.

## Status penerimaan

| Kriteria | Status |
|---|---|
| Source EA, panel, preset | Ditulis. Verifikasi kompilasi dan visual MT5 tertunda. |
| Multi-symbol, rekonsiliasi, restart, proteksi margin | Jalur kode tersedia. Perlu uji integrasi MT5. |
| Registri kandidat | 24.000 kombinasi parameter unik dari 10 keluarga offline. Deduplikasi tanda tangan identik opsional. Ambang korelasi kandidat dan jumlah tersisa belum terverifikasi. |
| Ensemble EA | Skor heuristik lima fitur. Kalibrasi probabilitas, estimasi return dan MAE/MFE, serta pelatihan belum tersedia. |
| Basket | Satu basket per simbol. Anggaran portofolio terpusat. Strategi belum memiliki posisi independen pada simbol yang sama. |
| Exit | Exit basket, trailing, batas waktu/risiko, invalidasi dan pengurangan hedging tersedia di source. Exit profit per posisi dan hedge unwind belum tersedia. |
| Pembelajaran, optimasi dan validasi pasar | Belum dijalankan. Portofolio produksi dan target pertumbuhan belum dapat dinilai. |
| EX5 | Belum dibuat. Lingkungan pengerjaan tidak menyediakan MetaEditor. |
