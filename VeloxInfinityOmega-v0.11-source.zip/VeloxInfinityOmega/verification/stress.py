from test_reference import approves, stopout_floor

scenarios = [
    ("baseline", 100, 80, 50, True),
    ("wider spread and slippage", 100, 250, 50, True),
    ("gap beyond modeled cushion", 100, 500, 50, True),
    ("lower leverage", 230, 100, 50, True),
    ("correlated portfolio shock", 140, 430, 50, True),
    ("money-mode stopout reserve", 100, 201, 700, False),
]
print("Illustrative guard arithmetic; equity 1000; fictional cash units")
print("scenario,margin,stress,stressed_equity,required_floor,decision")
for name, margin, stress, broker, percent in scenarios:
    floor = stopout_floor(margin, broker, percent)
    allow = approves(1000, margin, stress, broker, percent)
    print(f"{name},{margin},{stress},{1000-stress},{floor:.2f},{'allow' if allow else 'block'}")
