"""Reference arithmetic checks and deterministic stress in fictional cash units.

These are specification checks. They neither execute nor compile the MQL5 EA.
"""
import csv
import math
import unittest
from pathlib import Path


def gap(base, ratio, next_layer, tick):
    return math.ceil(base * ratio ** (next_layer - 1) / tick - 1e-9) * tick


def volume_floor(raw, minimum, step):
    return 0 if raw < minimum else math.floor(raw / step + 1e-9) * step


def stopout_floor(margin, broker, is_percent, min_margin=400):
    if is_percent:
        return margin * max(min_margin, broker + 100) / 100
    return max(margin * min_margin / 100, margin + max(0, broker))


def approves(equity, margin, stress, broker, is_percent, free_buffer=45):
    remaining = equity - stress
    return remaining >= stopout_floor(margin, broker, is_percent) and remaining - margin >= equity * free_buffer / 100


class ReferenceChecks(unittest.TestCase):
    def test_grid_interlayer(self):
        actual = [gap(10, 1.5, i, 0.125) for i in range(2, 6)]
        self.assertEqual(actual, [15, 22.5, 33.75, 50.625])
        self.assertEqual(sum(actual), 121.875)

    def test_grid_rounds_outward(self):
        self.assertEqual(gap(10, 1.5, 3, 1), 23)

    def test_grid_uses_next_index(self):
        self.assertAlmostEqual(gap(10, 1.1, 2, 0.01), 11.0, places=8)

    def test_lot_rounding(self):
        self.assertEqual(volume_floor(0.00999, 0.01, 0.01), 0)
        self.assertEqual(volume_floor(0.029, 0.01, 0.01), 0.02)
        self.assertLess(1.10 ** 5, 2 ** 5)

    def test_stopout_modes(self):
        self.assertEqual(stopout_floor(100, 50, True), 400)
        self.assertEqual(stopout_floor(100, 550, True), 650)
        self.assertEqual(stopout_floor(100, 700, False), 800)

    def test_stress(self):
        self.assertTrue(approves(1000, 100, 80, 50, True))
        self.assertFalse(approves(1000, 100, 500, 50, True))
        self.assertFalse(approves(1000, 230, 100, 50, True))
        self.assertFalse(approves(1000, 100, 201, 700, False))

    def test_registry(self):
        path = Path(__file__).resolve().parents[1] / "research" / "candidates.csv"
        with path.open(newline="") as stream:
            rows = list(csv.DictReader(stream))
        self.assertEqual(len(rows), 24000)
        self.assertEqual(len({row["id"] for row in rows}), 24000)
        self.assertEqual(len({row["family"] for row in rows}), 10)


if __name__ == "__main__":
    unittest.main(verbosity=2)
