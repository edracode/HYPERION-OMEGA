"""Enumerate actual feature rules and remove duplicate training-window signals.

Input CSV columns: time,open,high,low,close. Supply chronological completed bars.
Output candidates are an offline research artifact, never promoted automatically.
"""
import argparse
import csv
import hashlib
import itertools
import math
from functools import lru_cache

FAMILIES = ("ema_cross", "wma_cross", "roc", "z_fade", "donchian", "rsi_fade",
            "regression", "wick_rejection", "range_expansion", "autocorrelation_gate")


def registry():
    for family, fast, ratio, threshold, hold in itertools.product(
        FAMILIES, range(4, 34), (2, 3, 4, 5), (0.20, 0.35, 0.50, 0.65, 0.80), (1, 2, 4, 8)
    ):
        slow = fast * ratio
        yield f"{family}:{fast}:{slow}:{threshold:.2f}:{hold}", family, fast, slow, threshold, hold


def scale(window):
    return max(sum(abs(b - a) for a, b in zip(window, window[1:])) / (len(window) - 1), 1e-15)


def ema(window):
    value = window[0]
    factor = 2 / (len(window) + 1)
    for close in window[1:]:
        value += factor * (close - value)
    return value


def wma(window):
    return sum(i * value for i, value in enumerate(window, 1)) / (len(window) * (len(window) + 1) / 2)


def feature(family, fast, slow, window):
    close = [bar[3] for bar in window]
    short = close[-fast:]
    noise = scale(close)
    if family == "ema_cross":
        return math.tanh((ema(short) - ema(close)) / noise)
    if family == "wma_cross":
        return math.tanh((wma(short) - wma(close)) / noise)
    if family == "roc":
        return math.tanh((short[-1] - short[0]) / (noise * math.sqrt(fast)))
    if family == "z_fade":
        mean = sum(close) / slow
        deviation = math.sqrt(sum((value - mean) ** 2 for value in close) / slow)
        deviation = max(deviation, noise)
        return -math.tanh((sum(short) / fast - mean) / deviation)
    if family == "donchian":
        ceiling = max(bar[1] for bar in window[:-1])
        floor = min(bar[2] for bar in window[-fast:-1])
        return max(-1, min(1, (2 * close[-1] - ceiling - floor) / max(ceiling - floor, noise)))
    if family == "rsi_fade":
        delta = [b - a for a, b in zip(short, short[1:])]
        return -sum(delta) / max(sum(map(abs, delta)), noise)
    if family == "regression":
        center = (fast - 1) / 2
        slope = sum((i - center) * (value - short[0]) for i, value in enumerate(short))
        slope /= sum((i - center) ** 2 for i in range(fast))
        return math.tanh(slope / noise)
    if family == "wick_rejection":
        wick = sum((min(o, c) - l) - (h - max(o, c)) for o, h, l, c in window[-fast:]) / fast
        return math.tanh(wick / noise)
    if family == "range_expansion":
        baseline = sum(h - l for _, h, l, _ in window[:-fast]) / (slow - fast)
        impulse = sum(c - o for o, _, _, c in window[-fast:]) / fast
        return math.tanh(impulse / max(noise, baseline * 0.5))
    delta = [b - a for a, b in zip(close, close[1:])]
    persistence = sum(a * b for a, b in zip(delta, delta[1:])) / max(sum(x * x for x in delta), 1e-30)
    return math.tanh(persistence * (short[-1] - short[0]) / noise)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bars")
    parser.add_argument("--output", default="candidates.csv")
    parser.add_argument("--train-bars", type=int, default=500)
    args = parser.parse_args()
    candidates = list(registry())
    assert len(set(row[0] for row in candidates)) == len(candidates)
    print(f"{len(candidates)} unique parameter tuples across {len(FAMILIES)} rule families")
    bars = []
    if args.bars:
        with open(args.bars, newline="", encoding="utf-8-sig") as stream:
            rows = list(csv.DictReader(stream))[: args.train_bars]
        bars = [tuple(float(row[k]) for k in ("open", "high", "low", "close")) for row in rows]
        if len(bars) < 250 or any(not all(math.isfinite(v) and v > 0 for v in bar)
                                  or bar[1] < max(bar[0], bar[3]) or bar[2] > min(bar[0], bar[3])
                                  for bar in bars):
            parser.error("Need at least 250 valid OHLC rows in the training segment")

    @lru_cache(maxsize=12000)
    def scores(family, fast, slow):
        return tuple(feature(family, fast, slow, bars[i - slow : i])
                     for i in range(165, len(bars) + 1))

    seen = set()
    retained = 0
    with open(args.output, "w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(("id", "family", "fast", "slow", "threshold", "hold_bars", "training_signature"))
        for row in candidates:
            _, family, fast, slow, threshold, hold = row
            signature = ""
            if bars:
                decisions = bytes(2 if x >= threshold else 0 if x <= -threshold else 1
                                  for x in scores(family, fast, slow))
                if all(x == 1 for x in decisions):
                    continue
                signature = hashlib.sha256(decisions + bytes([hold])).hexdigest()
                if signature in seen:
                    continue
                seen.add(signature)
            writer.writerow((*row, signature))
            retained += 1
    print(f"Retained {retained}; empirical exact-signal pruning {'on' if bars else 'off'}")


if __name__ == "__main__":
    main()
