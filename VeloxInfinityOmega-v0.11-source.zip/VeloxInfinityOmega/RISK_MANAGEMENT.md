# Batas risiko

EA menggunakan stop loss broker pada entry. Saat averaging akun netting stop yang sudah terpasang dipertahankan. Proyeksi stres memasukkan seluruh basket EA yang dapat direkonsiliasi, tambahan adverse gap, spread, biaya, dan toleransi deviasi. Margin hasil OrderCheck dibandingkan dengan margin akun ditambah OrderCalcMargin, kemudian nilai yang lebih tinggi digunakan. Kalkulasi menyisakan buffer terhadap batas margin minimum dan stop-out broker. Proyeksi menyatakan modal yang tersisa pada shock yang ditentukan; jarak likuidasi lintas harga tidak dihitung.

Loss basket membatasi posisi setelah memperhitungkan floating P/L, biaya histori, dan estimasi biaya tutup. Komisi terpisah yang broker catat tanpa magic atau position identifier mungkin tidak teratribusi. Jika beberapa ticket hedging tutup ketika ticket lain masih terbuka, akuntansi basket terbuka belum membawa seluruh biaya dan P/L ticket yang sudah tidak aktif. Metrik realized berbasis deal dengan magic yang sesuai.

Penjaga global membaca equity, free margin, margin, baseline harian waktu server, dan peak equity akun. Latch menghentikan entry dan mencoba menutup posisi EA yang dapat ditangani. Gap, halt, koneksi putus, likuiditas, intervensi di akun netting, dan respons exit ambigu dapat membuat likuidasi tertunda atau kerugian melewati ambang. Pemulihan rekening berbagi posisi dengan program lain berada di luar cakupan. Saldo deposit dan withdrawal dapat menggeser baseline drawdown. Kunci berkas hanya berlaku dalam lingkungan terminal yang berbagi direktori common di mesin yang sama.

Riwayat M1 diselaraskan berdasarkan waktu bar untuk penalti korelasi. Ini estimasi jangka pendek. Tidak ada klaim proteksi terhadap setiap skenario korelasi, stop-out, atau perubahan persyaratan margin.

## Stress dan drawdown

`verification/stress-results.csv` berisi skenario deterministik dengan ekuitas awal 1000 dalam satuan fiktif. Analisis ini menguji batas aritmetika pada peningkatan margin dan kerugian. Jalur ekuitas pasar, maximum equity/balance drawdown, floating loss, dan probability of ruin membutuhkan backtest/forward test dan belum terukur.
