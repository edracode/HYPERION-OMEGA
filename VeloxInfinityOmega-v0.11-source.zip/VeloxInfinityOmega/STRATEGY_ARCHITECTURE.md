# Arsitektur

- VE-CME memeriksa posisi dan kandidat lintas simbol, memprioritaskan skor bertanda dikurangi spread relatif ATR, serta membatasi satu pengiriman entry per siklus. Exit diprioritaskan.
- VE-MSI dan VE-DAI memakai tren WMA 8 terhadap SMA 20, momentum, posisi terhadap rentang, mean reversion, dan perubahan quote. Bar indikator diambil dari shift 1. Skor di rentang −1 hingga 1 adalah skor arah heuristik. Quote imbalance hanya memakai perubahan bid/ask yang tersedia.
- VE-MRI membedakan naik, turun, range, volatilitas rendah/tinggi, breakout, reversal, price shock, dan likuiditas tidak stabil. Price shock diukur dari ATR dan pergeseran harga terhadap close terakhir. Kalender berita belum terintegrasi.
- VE-EGE menghitung D sebagai nilai tertinggi dari minimum broker, base points, dan pilihan skala ATR. Layer n menggunakan D × r^(n−1) dari fill sebelumnya dan dibulatkan ke atas sesuai tick size. r merespons tekanan tren, ATR relatif, spread, drawdown, dan korelasi posisi.
- VE-ALE mengubah anggaran risiko ke volume memakai OrderCalcProfit atas stop dan gap. Mode adaptive memakai q^(n−1), dengan q dibatasi 0,65 hingga 1,30. Kebijakan sizing alternatif memakai estimasi deterministik. Pemilihan berbasis hasil out-of-sample belum terintegrasi.
- VE-ASE memproses snapshot tick per simbol dari event chart dan timer. Timestamp milidetik serta histori perubahan quote digunakan dalam skor mikrostruktur. MaxHoldSeconds menerima 1 hingga 900 detik. Cadence event dan broker membatasi evaluasi. Posisi yang baru ditutup dapat dievaluasi lagi setelah cooldown.
- Order request melewati proyeksi, OrderCheck, dan penilaian retcode. Jurnal entry dan exit menggunakan Global Variables serta kunci berkas lokal per login/magic. Pada netting riwayat deal diperiksa untuk mendeteksi intervensi dengan magic berbeda. Pada hedging penutupan memilih ticket.
- Dashboard memisahkan equity akun dari realized P/L EA berdasarkan magic. Waktu permintaan diukur dari pemanggilan sinkron dan mencakup overhead terminal. BE memakai sensitivitas satu tick sebagai pendekatan lokal.

## Registri riset

Jalankan `python3 research/registry.py --output candidates.csv`. Serahkan data OHLC bar tertutup berurutan melalui `--bars FILE --train-bars 500` untuk membuang kandidat yang tidak memberi sinyal atau bertanda tangan identik pada jendela latih dengan holding period sama. Kandidat yang hanya berkorelasi tinggi masih dapat lolos. Registri offline belum dipromosikan menjadi strategi aktif EA dan horizon dalam bar dicatat sebagai parameter riset.
